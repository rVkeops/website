import { Link } from 'react-router-dom';
import { ArrowLeft, FileText } from 'lucide-react';
import type { Lang } from '../data/translations';
import { translations } from '../data/translations';
import Footer from '../components/Footer';
import CookieBanner from '../components/CookieBanner';

export default function TermsPage({ lang }: { lang: Lang }) {
  const t = translations[lang];
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white" lang={t.htmlLang}>
      <nav className="bg-[#0a0a0f]/95 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-4">
          <Link to={`/${lang}`} className="flex items-center gap-2 text-white/60 hover:text-[#c9a84c] transition-colors text-sm">
            <ArrowLeft size={16} /><span>Back</span>
          </Link>
          <span className="text-white/20">|</span>
          <Link to={`/${lang}`} className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-[#c9a84c] flex items-center justify-center text-[#0a0a0f] font-bold text-xs">M</div>
            <span className="text-white font-semibold text-sm">MRIntelligence</span>
          </Link>
        </div>
      </nav>
      <main className="max-w-3xl mx-auto px-6 py-16">
        <div className="flex items-center gap-3 mb-2">
          <FileText size={20} className="text-[#c9a84c]" />
          <span className="text-[#c9a84c] text-sm font-medium">Legal</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>{t.terms.title}</h1>
        <p className="text-white/40 text-sm mb-12">{t.terms.updated}</p>
        <div className="space-y-8">
          {t.terms.sections.map((s, i) => (
            <div key={i}>
              <h2 className="text-xl font-semibold mb-3 text-[#e8d5a3]">{s.h2}</h2>
              <p className="text-white/60 text-sm leading-relaxed">{s.content}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 pt-8 border-t border-white/10">
          <Link to={`/${lang}/privacy`} className="text-[#c9a84c] text-sm hover:underline">View Privacy Policy</Link>
        </div>
      </main>
      <Footer lang={lang} />
      <CookieBanner lang={lang} />
    </div>
  );
}
