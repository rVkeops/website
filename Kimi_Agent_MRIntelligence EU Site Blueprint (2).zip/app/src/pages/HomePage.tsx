import { useState, useEffect, useRef } from 'react';
import { Shield, Globe, FileText, CreditCard, Plane, ScrollText, Check, ChevronDown, Mail, Phone, MapPin, Clock, Send, CheckCircle } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import CookieBanner from '../components/CookieBanner';
import { trpc } from '@/providers/trpc';
import type { Lang } from '../data/translations';
import { translations } from '../data/translations';

const serviceIcons = [CreditCard, Globe, Shield, FileText, Plane, ScrollText];

function AnimatedCounter({ target, suffix = '' }: { target: string; suffix?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const num = parseInt(target.replace(/\D/g, ''));
  const prefix = target.replace(/[0-9]/g, '').replace(suffix, '');

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let current = 0;
          const step = Math.max(1, Math.floor(num / 60));
          const timer = setInterval(() => {
            current += step;
            if (current >= num) { current = num; clearInterval(timer); }
            setVal(current);
          }, 16);
          observer.disconnect();
        }
      }, { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [num]);

  return <span ref={ref}>{prefix}{val.toLocaleString()}{suffix}</span>;
}

export default function HomePage({ lang }: { lang: Lang }) {
  const [currentLang, setCurrentLang] = useState<Lang>(lang);
  useEffect(() => { setCurrentLang(lang); }, [lang]);
  const t = translations[currentLang];
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [gdprChecked, setGdprChecked] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', caseType: '', amount: '', description: '' });

  const createLead = trpc.leads.create.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setFormData({ name: '', email: '', phone: '', caseType: '', amount: '', description: '' });
      setGdprChecked(false);
      setTimeout(() => setSubmitted(false), 5000);
    },
  });

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gdprChecked || !formData.name || !formData.email || !formData.caseType) return;
    createLead.mutate({
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      caseType: formData.caseType,
      amount: formData.amount,
      description: formData.description,
      language: currentLang,
      gdprConsent: 'yes',
    });
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white" lang={t.htmlLang}>
      <Navbar lang={currentLang} onLangChange={setCurrentLang} />

      {/* ===== HERO ===== */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a0f] via-[#13131f] to-[#0f1525]" />
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 30% 20%, rgba(201,168,76,0.08) 0%, transparent 60%)' }} />
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 70% 80%, rgba(201,168,76,0.05) 0%, transparent 50%)' }} />
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center pt-24">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#c9a84c]/10 border border-[#c9a84c]/30 mb-8">
            <span className="w-2 h-2 rounded-full bg-[#c9a84c] animate-pulse" />
            <span className="text-[#c9a84c] text-sm font-medium">{t.hero.badge}</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            {t.hero.h1}
          </h1>
          <p className="text-lg text-white/60 max-w-2xl mx-auto mb-10 leading-relaxed">{t.hero.subtitle}</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <button onClick={() => scrollTo('contact')} className="px-8 py-4 bg-[#c9a84c] text-[#0a0a0f] font-semibold rounded-xl hover:bg-[#e8d5a3] transition-all hover:scale-105 shadow-lg shadow-[#c9a84c]/20">
              {t.hero.ctaStart}
            </button>
            <button onClick={() => scrollTo('process')} className="px-8 py-4 border border-white/20 text-white rounded-xl hover:bg-white/5 transition-all">
              {t.hero.ctaHow}
            </button>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-6 mb-16">
            {[{ icon: Shield, text: t.hero.trust1 }, { icon: FileText, text: t.hero.trust2 }, { icon: Globe, text: t.hero.trust3 }].map((b, i) => (
              <div key={i} className="flex items-center gap-2 text-white/50 text-sm">
                <b.icon size={16} className="text-[#c9a84c]" />
                <span>{b.text}</span>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-6 max-w-xl mx-auto">
            {[
              { label: t.hero.stats.label1, val: t.hero.stats.val1 },
              { label: t.hero.stats.label2, val: t.hero.stats.val2 },
              { label: t.hero.stats.label3, val: t.hero.stats.val3 },
            ].map((s, i) => (
              <div key={i} className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-[#c9a84c]"><AnimatedCounter target={s.val} /></div>
                <div className="text-white/40 text-xs mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="text-white/30 text-xs">Scroll</span>
          <div className="w-5 h-8 rounded-full border border-white/20 flex justify-center pt-1">
            <div className="w-1 h-2 bg-[#c9a84c] rounded-full animate-bounce" />
          </div>
        </div>
      </section>

      {/* ===== SERVICES ===== */}
      <section id="services" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>{t.services.title}</h2>
            <p className="text-white/50 max-w-xl mx-auto">{t.services.subtitle}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {t.services.items.map((s, i) => {
              const Icon = serviceIcons[i];
              return (
                <div key={i} className="group p-8 rounded-2xl bg-[#13131f]/60 border border-white/5 hover:border-[#c9a84c]/30 transition-all duration-300 hover:-translate-y-1">
                  <div className="w-12 h-12 rounded-xl bg-[#c9a84c]/10 flex items-center justify-center mb-5 group-hover:bg-[#c9a84c]/20 transition-colors">
                    <Icon size={22} className="text-[#c9a84c]" />
                  </div>
                  <h3 className="text-lg font-semibold mb-3">{s.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{s.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ===== PROCESS ===== */}
      <section id="process" className="py-24 relative bg-[#0d0d14]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>{t.process.title}</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {t.process.steps.map((step, i) => (
              <div key={i} className="relative p-8 rounded-2xl bg-gradient-to-br from-[#13131f] to-[#0f0f1a] border border-white/5">
                <div className="text-4xl font-bold text-[#c9a84c]/20 mb-4">{step.num}</div>
                <h3 className="text-lg font-semibold mb-3">{step.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{step.desc}</p>
                {i < 3 && <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-px bg-[#c9a84c]/30" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== PRICING ===== */}
      <section id="pricing" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>{t.pricing.title}</h2>
            <p className="text-white/50 max-w-2xl mx-auto">{t.pricing.subtitle}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {t.pricing.tiers.map((tier, i) => (
              <div key={i} className={`relative p-8 rounded-2xl ${tier.featured ? 'bg-gradient-to-br from-[#c9a84c]/10 to-[#13131f] border-2 border-[#c9a84c]/40 scale-105 z-10' : 'bg-[#13131f]/60 border border-white/5'}`}>
                {tier.featured && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-[#c9a84c] text-[#0a0a0f] text-xs font-bold rounded-full">POPULAR</div>
                )}
                <h3 className="text-lg font-semibold mb-2">{tier.name}</h3>
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-3xl font-bold text-[#c9a84c]">{tier.price}</span>
                </div>
                <p className="text-white/40 text-xs mb-1">{tier.unit}</p>
                <p className="text-white/50 text-sm mb-6">{tier.desc}</p>
                <ul className="space-y-3 mb-8">
                  {tier.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-2 text-sm text-white/60">
                      <Check size={14} className="text-[#c9a84c] shrink-0" />{f}
                    </li>
                  ))}
                </ul>
                <button onClick={() => scrollTo('contact')} className={`w-full py-3 rounded-xl font-semibold transition-all ${tier.featured ? 'bg-[#c9a84c] text-[#0a0a0f] hover:bg-[#e8d5a3]' : 'border border-white/20 text-white hover:bg-white/5'}`}>
                  {t.hero.ctaStart}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== TESTIMONIALS ===== */}
      <section className="py-24 relative bg-[#0d0d14]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>{t.testimonials.title}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {t.testimonials.items.map((item, i) => (
              <div key={i} className="p-8 rounded-2xl bg-[#13131f]/60 border border-white/5 relative">
                <div className="text-5xl text-[#c9a84c]/20 absolute top-4 left-6">&ldquo;</div>
                <p className="text-white/70 text-sm leading-relaxed mb-6 pt-8 relative z-10">{item.text}</p>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-sm">{item.name}</p>
                    <p className="text-white/40 text-xs">{item.loc}</p>
                  </div>
                  {item.amount && <span className="text-[#c9a84c] text-sm font-bold">{item.amount}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FAQ ===== */}
      <section id="faq" className="py-24 relative">
        <div className="max-w-3xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>{t.faq.title}</h2>
          </div>
          <div className="space-y-3">
            {t.faq.items.map((item, i) => (
              <div key={i} className="rounded-xl bg-[#13131f]/60 border border-white/5 overflow-hidden">
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex items-center justify-between p-5 text-left">
                  <span className="text-sm font-medium pr-4">{item.q}</span>
                  <ChevronDown size={18} className={`text-[#c9a84c] shrink-0 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                <div className={`overflow-hidden transition-all duration-300 ${openFaq === i ? 'max-h-96' : 'max-h-0'}`}>
                  <p className="px-5 pb-5 text-white/50 text-sm leading-relaxed">{item.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CONTACT ===== */}
      <section id="contact" className="py-24 relative bg-[#0d0d14]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>{t.contact.title}</h2>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
            {/* Left: info */}
            <div className="space-y-8">
              {[
                { icon: Mail, label: t.contact.email, href: `mailto:${t.contact.email}` },
                { icon: Phone, label: t.contact.phone, href: `tel:${t.contact.phone}` },
                { icon: MapPin, label: t.contact.address, href: '#' },
                { icon: Clock, label: t.contact.hours, href: '#' },
              ].map((c, i) => (
                <div key={i} className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[#c9a84c]/10 flex items-center justify-center shrink-0">
                    <c.icon size={18} className="text-[#c9a84c]" />
                  </div>
                  <div>
                    <a href={c.href} className="text-white/50 text-sm hover:text-[#c9a84c] transition-colors">{c.label}</a>
                  </div>
                </div>
              ))}
            </div>
            {/* Right: form */}
            {submitted ? (
              <div className="flex flex-col items-center justify-center gap-4 p-8 rounded-2xl bg-[#13131f]/60 border border-[#c9a84c]/20">
                <CheckCircle size={48} className="text-[#c9a84c]" />
                <h3 className="text-xl font-semibold text-[#c9a84c]">Thank you!</h3>
                <p className="text-white/60 text-sm text-center">Your request has been submitted. We will contact you within 48 hours.</p>
              </div>
            ) : (
              <form className="space-y-4" onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder={t.contact.formName} required className="w-full px-4 py-3 rounded-xl bg-[#13131f] border border-white/10 text-white text-sm placeholder:text-white/30 focus:border-[#c9a84c]/50 focus:outline-none" />
                  <input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} placeholder={t.contact.formEmail} required className="w-full px-4 py-3 rounded-xl bg-[#13131f] border border-white/10 text-white text-sm placeholder:text-white/30 focus:border-[#c9a84c]/50 focus:outline-none" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <input type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder={t.contact.formPhone} className="w-full px-4 py-3 rounded-xl bg-[#13131f] border border-white/10 text-white text-sm placeholder:text-white/30 focus:border-[#c9a84c]/50 focus:outline-none" />
                  <select value={formData.caseType} onChange={e => setFormData({...formData, caseType: e.target.value})} required className="w-full px-4 py-3 rounded-xl bg-[#13131f] border border-white/10 text-white text-sm focus:border-[#c9a84c]/50 focus:outline-none appearance-none">
                    <option value="">{t.contact.formCase}</option>
                    {t.contact.cases.map((c, i) => <option key={i} value={c}>{c}</option>)}
                  </select>
                </div>
                <input type="text" value={formData.amount} onChange={e => setFormData({...formData, amount: e.target.value})} placeholder={t.contact.formAmount} className="w-full px-4 py-3 rounded-xl bg-[#13131f] border border-white/10 text-white text-sm placeholder:text-white/30 focus:border-[#c9a84c]/50 focus:outline-none" />
                <textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder={t.contact.formDesc} rows={4} className="w-full px-4 py-3 rounded-xl bg-[#13131f] border border-white/10 text-white text-sm placeholder:text-white/30 focus:border-[#c9a84c]/50 focus:outline-none resize-none" />
                <label className="flex items-start gap-3 cursor-pointer">
                  <input type="checkbox" checked={gdprChecked} onChange={(e) => setGdprChecked(e.target.checked)} className="mt-1 accent-[#c9a84c]" />
                  <span className="text-white/50 text-xs leading-relaxed">{t.contact.formGdpr}</span>
                </label>
                {createLead.isError && <p className="text-red-400 text-sm">Error submitting. Please try again.</p>}
                <button type="submit" disabled={!gdprChecked || createLead.isPending} className={`w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all ${gdprChecked ? 'bg-[#c9a84c] text-[#0a0a0f] hover:bg-[#e8d5a3]' : 'bg-white/10 text-white/30 cursor-not-allowed'}`}>
                  <Send size={16} />{createLead.isPending ? 'Sending...' : t.contact.submit}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      <Footer lang={currentLang} />
      <CookieBanner lang={currentLang} />
    </div>
  );
}
