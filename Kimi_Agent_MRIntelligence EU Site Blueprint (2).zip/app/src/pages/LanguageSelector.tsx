import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Globe } from 'lucide-react';

const langs = [
  { code: 'pt', name: 'Portugues', flag: '🇵🇹', desc: 'Especialistas em recuperacao de fundos' },
  { code: 'es', name: 'Espanol', flag: '🇪🇸', desc: 'Expertos en recuperacion de fondos' },
  { code: 'dk', name: 'Dansk', flag: '🇩🇰', desc: 'Eksperter i genopretning af midler' },
  { code: 'it', name: 'Italiano', flag: '🇮🇹', desc: 'Esperti nel recupero di fondi' },
  { code: 'en', name: 'English', flag: '🇬🇧', desc: 'Fund recovery experts' },
];

export default function LanguageSelector() {
  const navigate = useNavigate();

  useEffect(() => {
    const browserLang = navigator.language.slice(0, 2);
    const langMap: Record<string, string> = { pt: 'pt', es: 'es', da: 'dk', it: 'it', en: 'en' };
    const target = langMap[browserLang] || 'en';
    navigate(`/${target}`, { replace: true });
  }, [navigate]);

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center px-6">
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a0f] via-[#13131f] to-[#0f1525]" />
      <div className="relative z-10 max-w-lg w-full">
        <div className="text-center mb-12">
          <div className="w-16 h-16 rounded-2xl bg-[#c9a84c]/10 flex items-center justify-center mx-auto mb-6">
            <Globe size={28} className="text-[#c9a84c]" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>MRIntelligence</h1>
          <p className="text-white/50">Select your language / Selecione o idioma</p>
        </div>
        <div className="space-y-3">
          {langs.map((l) => (
            <button
              key={l.code}
              onClick={() => navigate(`/${l.code}`)}
              className="w-full flex items-center gap-4 p-5 rounded-2xl bg-[#13131f]/60 border border-white/5 hover:border-[#c9a84c]/30 transition-all duration-300 hover:-translate-y-0.5 group"
            >
              <span className="text-3xl">{l.flag}</span>
              <div className="text-left">
                <p className="text-white font-semibold group-hover:text-[#c9a84c] transition-colors">{l.name}</p>
                <p className="text-white/40 text-sm">{l.desc}</p>
              </div>
              <div className="ml-auto w-8 h-8 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-[#c9a84c]/10 transition-colors">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M5 2L10 7L5 12" stroke="#c9a84c" strokeWidth="1.5"/></svg>
              </div>
            </button>
          ))}
        </div>
        <p className="text-white/20 text-xs text-center mt-8">Redirecting based on your browser language...</p>
      </div>
    </div>
  );
}
