import { useState } from 'react';
import { Link } from 'react-router-dom';
import { trpc } from '@/providers/trpc';
import { RefreshCw, ArrowLeft, Mail, Phone, Clock, Users, TrendingUp, CheckCircle } from 'lucide-react';

const statusColors: Record<string, string> = {
  new: 'bg-blue-500/20 text-blue-400',
  contacted: 'bg-yellow-500/20 text-yellow-400',
  in_progress: 'bg-orange-500/20 text-orange-400',
  resolved: 'bg-green-500/20 text-green-400',
  closed: 'bg-gray-500/20 text-gray-400',
};

const langFlags: Record<string, string> = {
  pt: '🇵🇹', es: '🇪🇸', dk: '🇩🇰', it: '🇮🇹', en: '🇬🇧',
};

export default function AdminPage() {
  const utils = trpc.useUtils();
  const { data: leads, isLoading } = trpc.leads.list.useQuery();
  const updateStatus = trpc.leads.updateStatus.useMutation({
    onSuccess: () => utils.leads.list.invalidate(),
  });
  const [filter, setFilter] = useState('all');

  const filteredLeads = leads?.filter(l => filter === 'all' || l.status === filter) ?? [];
  const stats = {
    total: leads?.length ?? 0,
    new: leads?.filter(l => l.status === 'new').length ?? 0,
    contacted: leads?.filter(l => l.status === 'contacted').length ?? 0,
    inProgress: leads?.filter(l => l.status === 'in_progress').length ?? 0,
    resolved: leads?.filter(l => l.status === 'resolved').length ?? 0,
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <nav className="bg-[#0a0a0f]/95 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-4">
          <Link to="/en" className="flex items-center gap-2 text-white/60 hover:text-[#c9a84c] transition-colors text-sm">
            <ArrowLeft size={16} /><span>Back to Site</span>
          </Link>
          <span className="text-white/20">|</span>
          <div className="w-7 h-7 rounded-md bg-[#c9a84c] flex items-center justify-center text-[#0a0a0f] font-bold text-xs">M</div>
          <span className="text-white font-semibold text-sm">MRIntelligence Admin</span>
          <div className="ml-auto flex items-center gap-3">
            <button onClick={() => utils.leads.list.invalidate()} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#c9a84c]/10 text-[#c9a84c] text-sm hover:bg-[#c9a84c]/20 transition-colors">
              <RefreshCw size={14} /> Refresh
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-8">
          {[
            { icon: Users, label: 'Total', value: stats.total, color: 'text-white' },
            { icon: Clock, label: 'New', value: stats.new, color: 'text-blue-400' },
            { icon: Mail, label: 'Contacted', value: stats.contacted, color: 'text-yellow-400' },
            { icon: TrendingUp, label: 'In Progress', value: stats.inProgress, color: 'text-orange-400' },
            { icon: CheckCircle, label: 'Resolved', value: stats.resolved, color: 'text-green-400' },
          ].map((s, i) => (
            <div key={i} className="p-4 rounded-xl bg-[#13131f]/60 border border-white/5">
              <div className="flex items-center gap-2 mb-2">
                <s.icon size={16} className={s.color} />
                <span className="text-white/40 text-xs">{s.label}</span>
              </div>
              <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            </div>
          ))}
        </div>

        {/* Filter tabs */}
        <div className="flex flex-wrap gap-2 mb-6">
          {['all', 'new', 'contacted', 'in_progress', 'resolved', 'closed'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filter === f ? 'bg-[#c9a84c] text-[#0a0a0f]' : 'bg-[#13131f] text-white/60 hover:text-white'}`}>
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1).replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Leads table */}
        {isLoading ? (
          <div className="text-center py-20 text-white/40">Loading leads...</div>
        ) : filteredLeads.length === 0 ? (
          <div className="text-center py-20 text-white/40">
            <p className="text-lg mb-2">No leads yet</p>
            <p className="text-sm">Leads submitted through the contact form will appear here.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredLeads.map((lead) => (
              <div key={lead.id} className="p-5 rounded-xl bg-[#13131f]/60 border border-white/5 hover:border-white/10 transition-all">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-lg">{langFlags[lead.language] ?? '🌍'}</span>
                      <h3 className="font-semibold text-sm truncate">{lead.name}</h3>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[lead.status] ?? 'bg-gray-500/20 text-gray-400'}`}>
                        {lead.status}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-xs text-white/40">
                      <span className="flex items-center gap-1"><Mail size={12} />{lead.email}</span>
                      {lead.phone && <span className="flex items-center gap-1"><Phone size={12} />{lead.phone}</span>}
                      <span>{lead.caseType}</span>
                      {lead.amount && <span className="text-[#c9a84c]">{lead.amount}</span>}
                    </div>
                    {lead.description && <p className="text-white/30 text-xs mt-2 line-clamp-2">{lead.description}</p>}
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-white/20 text-xs">{new Date(lead.createdAt).toLocaleDateString()}</span>
                    <select
                      value={lead.status}
                      onChange={(e) => updateStatus.mutate({ id: lead.id, status: e.target.value as any })}
                      className="px-3 py-1.5 rounded-lg bg-[#1a1a2a] border border-white/10 text-xs text-white/70 focus:outline-none focus:border-[#c9a84c]/50"
                    >
                      <option value="new">New</option>
                      <option value="contacted">Contacted</option>
                      <option value="in_progress">In Progress</option>
                      <option value="resolved">Resolved</option>
                      <option value="closed">Closed</option>
                    </select>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
