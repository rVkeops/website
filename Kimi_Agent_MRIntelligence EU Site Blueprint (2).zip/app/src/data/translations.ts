export type Lang = 'pt' | 'es' | 'dk' | 'it' | 'en';

export const translations: Record<Lang, {
  langCode: string;
  htmlLang: string;
  locale: string;
  metaDesc: string;
  nav: { services: string; howItWorks: string; pricing: string; faq: string; contact: string };
  hero: { badge: string; h1: string; subtitle: string; ctaStart: string; ctaHow: string; trust1: string; trust2: string; trust3: string; stats: { label1: string; val1: string; label2: string; val2: string; label3: string; val3: string } };
  services: { title: string; subtitle: string; items: { title: string; desc: string }[] };
  process: { title: string; steps: { num: string; title: string; desc: string }[] };
  pricing: { title: string; subtitle: string; tiers: { name: string; price: string; unit: string; desc: string; featured: boolean; features: string[] }[] };
  testimonials: { title: string; items: { name: string; loc: string; text: string; amount?: string }[] };
  faq: { title: string; items: { q: string; a: string }[] };
  contact: { title: string; email: string; phone: string; address: string; hours: string; formName: string; formEmail: string; formPhone: string; formCase: string; formAmount: string; formDesc: string; formGdpr: string; submit: string; cases: string[] };
  footer: { disclaimer: string; col1: string; col2: string; col3: string; col4: string; copyright: string };
  privacy: { title: string; updated: string; sections: { h2: string; content: string }[] };
  terms: { title: string; updated: string; sections: { h2: string; content: string }[] };
  cookieBanner: { text: string; accept: string; decline: string; privacyLink: string };
}> = {
  pt: {
    langCode: 'pt', htmlLang: 'pt-PT', locale: 'pt_PT',
    metaDesc: 'MRIntelligence — Especialistas em recuperacao de fundos de transacoes fraudulentas. Portugal, Espanha, Dinamarca, Italia. Sem recuperacao, sem taxa.',
    nav: { services: 'Servicos', howItWorks: 'Como Funciona', pricing: 'Precos', faq: 'FAQ', contact: 'Contacto' },
    hero: {
      badge: 'Especialistas em Recuperacao de Fundos',
      h1: 'Recupere o Seu Dinheiro de Transacoes Fraudulentas',
      subtitle: 'A primeira consultoria europeia especializada em recuperacao de chargebacks para consumidores. Operamos em Portugal, Espanha, Dinamarca e Italia com um modelo de taxa de sucesso.',
      ctaStart: 'Iniciar Recuperacao', ctaHow: 'Como Funciona',
      trust1: 'Sem Recuperacao, Sem Taxa', trust2: 'Conforme RGPD', trust3: '100% Portugues',
      stats: { label1: 'Casos Resolvidos', val1: '1.240+', label2: 'Taxa de Sucesso', val2: '87%', label3: 'Recuperacao Media', val3: '3.200 EUR' }
    },
    services: {
      title: 'Os Nossos Servicos', subtitle: 'Solucoes especializadas para cada tipo de disputa financeira',
      items: [
        { title: 'Chargebacks Bancarios', desc: 'Gestao completa do processo de chargeback com o seu banco. Documentacao, follow-up e negociacao ate a recuperacao total.' },
        { title: 'Disputas de Jogo Online', desc: 'Especialistas em disputas contra operadores de jogo online licenciados pela SRIJ e outras autoridades europeias.' },
        { title: 'Recuperacao de Fraude Online', desc: 'Recuperacao de fundos perdidos em esquemas de fraude online, investimentos falsos e phishing financeiro.' },
        { title: 'Subscricoes Abusivas', desc: 'Cancelamento e recuperacao de valores cobrados indevidamente por subscricoes ocultas e servicos nao solicitados.' },
        { title: 'Fraude no Turismo', desc: 'Recuperacao de pagamentos por reservas falsas, alojamentos inexistentes e servicos turisticos nao prestados.' },
        { title: 'Documentacao Legal', desc: 'Preparacao profissional de toda a documentacao necessaria para apresentacao eficaz da sua reclamacao.' }
      ]
    },
    process: {
      title: 'Como Funciona', steps: [
        { num: '01', title: 'Avaliacao Gratuita', desc: 'Preenche o formulario com os detalhes do seu caso. Avaliamos gratuitamente a viabilidade da recuperacao.' },
        { num: '02', title: 'Analise de Viabilidade', desc: 'A nossa equipa analisa documentacao, transacoes e prazos legais aplicaveis ao seu caso especifico.' },
        { num: '03', title: 'Preparacao e Submissao', desc: 'Elaboramos toda a documentacao necessaria e submetemos o processo junto das entidades competentes.' },
        { num: '04', title: 'Recuperacao', desc: 'Acompanhamos todo o processo ate a recuperacao dos seus fundos. Paga apenas quando recuperar.' }
      ]
    },
    pricing: {
      title: 'Precos Transparentes', subtitle: 'Sem custos ocultos. Paga apenas pela avaliacao inicial e uma percentagem apenas se recuperarmos o seu dinheiro.',
      tiers: [
        { name: 'Avaliacao', price: 'EUR 50', unit: 'taxa unica', desc: 'Analise inicial completa do seu caso e parecer de viabilidade.', featured: false, features: ['Analise detalhada do caso', 'Parecer de viabilidade', 'Plano de recuperacao', 'Resposta em 48h'] },
        { name: 'Recuperacao Standard', price: '20%', unit: 'do valor recuperado', desc: 'A nossa opcao mais popular para a maioria dos casos de chargeback e fraude.', featured: true, features: ['Toda a documentacao incluida', 'Submissao e follow-up', 'Comunicacao com entidades', 'Paga apenas se recuperar'] },
        { name: 'Casos Complexos', price: '25%', unit: 'do valor recuperado', desc: 'Para casos judiciais, valores elevados ou situacoes que exigem estrategia avancada.', featured: false, features: ['Estrategia personalizada', 'Documentacao legal avancada', 'Acompanhamento judicial', 'Prioridade maxima'] }
      ]
    },
    testimonials: {
      title: 'O Que Dizem os Nossos Clientes',
      items: [
        { name: 'Ana M.', loc: 'Lisboa', text: 'Recuperei EUR 3.200 de uma transacao fraudulenta. O processo foi transparente do inicio ao fim. Recomendo a 100%.', amount: 'EUR 3.200' },
        { name: 'Ricardo S.', loc: 'Porto', text: 'Pensei que o dinheiro estava perdido. A MRIntelligence conseguiu recuperar tudo em menos de 3 meses. Profissionais excecionais.', amount: '' },
        { name: 'Carla F.', loc: 'Faro', text: 'Servico impecavel. A equipa explica cada passo e mantem-nos informados. Sem surpresas, sem custos ocultos.', amount: '' }
      ]
    },
    faq: {
      title: 'Perguntas Frequentes',
      items: [
        { q: 'Quanto tempo demora a recuperacao?', a: 'O prazo medio e de 30 a 90 dias, dependendo do tipo de caso e da complexidade. Casos simples de chargeback resolvem-se em 30-45 dias, enquanto casos judiciais podem demorar 3-6 meses.' },
        { q: 'Tenho de pagar antecipadamente?', a: 'Apenas a taxa de avaliacao de EUR 50 e paga antecipadamente. A taxa de sucesso so e cobrada apos a recuperacao efetiva dos fundos. Sem recuperacao, sem taxa adicional.' },
        { q: 'Que tipos de casos aceitam?', a: 'Aceitamos chargebacks bancarios, disputas de jogo online, fraudes de e-commerce, subscricoes abusivas, fraudes turisticas e outras transacoes nao autorizadas. Avaliamos cada caso individualmente.' },
        { q: 'Os meus dados estao seguros?', a: 'Sim. Somos totalmente conformes com o RGPD. Todos os dados sao encriptados com AES-256, transmitidos via SSL/TLS e acedidos apenas por pessoal autorizado. Nunca partilhamos dados com terceiros sem consentimento.' },
        { q: 'Transacoes antigas podem ser recuperadas?', a: 'Depende do prazo legal aplicavel. Em Portugal, o prazo para chargebacks e geralmente de 540 dias apos a transacao. Para outros tipos de disputa, os prazos variam. Contacte-nos para avaliacao especifica.' },
        { q: 'Aceitam clientes de outros paises?', a: 'Sim. Operamos em Portugal, Espanha, Dinamarca e Italia. Para clientes de outros paises da UE, avaliamos caso a caso conforme a jurisdicao aplicavel.' }
      ]
    },
    contact: {
      title: 'Contacte-nos', email: 'pt@mrintelligence.eu', phone: '+351 21 012 3456',
      address: 'MRIntelligence, Rua Augusta 100, 1100-053 Lisboa, Portugal',
      hours: 'Seg - Sex: 09:00 - 18:00 (WEST)',
      formName: 'Nome completo', formEmail: 'Email', formPhone: 'Telefone',
      formCase: 'Tipo de caso', formAmount: 'Valor (EUR)', formDesc: 'Descricao do caso',
      formGdpr: 'Confirmo que li e aceito a Politica de Privacidade e autorizo o tratamento dos meus dados pessoais para fins de avaliacao do caso, em conformidade com o RGPD.',
      submit: 'Enviar Pedido',
      cases: ['Chargeback bancario', 'Fraude online', 'Jogo online', 'Subscricao abusiva', 'Fraude turistica', 'Outro']
    },
    footer: {
      disclaimer: 'MRIntelligence e uma consultoria de gestao. Nao somos uma instituicao financeira nem prestamos servicos juridicos regulamentados. Os servicos consistem em informacao, preparacao de documentacao e orientacao em processos de disputa.',
      col1: 'MRIntelligence — Especialistas em recuperacao de fundos para consumidores na Europa.',
      col2: 'Servicos\nChargeback\nFraude Online\nJogo Online\nSubscricoes\nTurismo',
      col3: 'Legal\nPolitica de Privacidade\nTermos de Servico\nPolitica de Cookies',
      col4: 'Contacto\npt@mrintelligence.eu\n+351 21 012 3456\nLisboa, Portugal',
      copyright: '2026 MRIntelligence. Todos os direitos reservados.'
    },
    privacy: {
      title: 'Politica de Privacidade', updated: 'Atualizado: 7 de maio de 2026',
      sections: [
        { h2: '1. Responsavel pelo Tratamento', content: 'MRIntelligence, com sede em Lisboa, Portugal, e responsavel pelo tratamento dos dados pessoais nos termos do RGPD. Email: privacy-pt@mrintelligence.eu' },
        { h2: '2. Dados que recolhemos', content: 'Dados de identidade (nome, NIF/passaporte), contacto (email, telefone), dados financeiros (detalhes da transacao, valor), dados do caso (descricao, documentacao anexa) e dados tecnicos (IP, cookies).' },
        { h2: '3. Base legal', content: 'Art. 6(1)(a) — Consentimento; (b) — Execucao de contrato; (c) — Obrigacao legal; (f) — Interesses legitimos (prevencao de fraude).' },
        { h2: '4. Direitos do titular', content: 'Direito de acesso, retificacao, apagamento, limitacao, portabilidade e oposicao (Art. 15-21 RGPD). Contacto: privacy-pt@mrintelligence.eu' },
        { h2: '5. Prazo de conservacao', content: 'Casos ativos: 6 anos apos encerramento. Casos recusados: 2 anos. Dados de contacto para marketing: ate revogacao do consentimento.' },
        { h2: '6. Seguranca', content: 'Encriptacao AES-256, SSL/TLS, acesso baseado em funcoes, backups diarios, auditorias trimestrais.' },
        { h2: '7. Terceiros', content: 'Stripe (pagamentos), provedor de email (Mailgun/Postmark), hospedagem cloud (AWS EU), analises (Matomo, auto-hospedado).' },
        { h2: '8. Reclamacoes', content: 'CNPD — Comissao Nacional de Protecao de Dados (Portugal): www.cnpd.pt' }
      ]
    },
    terms: {
      title: 'Termos de Servico', updated: 'Atualizado: 7 de maio de 2026',
      sections: [
        { h2: '1. Natureza dos Servicos', content: 'A MRIntelligence presta servicos de consultoria de gestao, nao servicos juridicos regulamentados nem servicos financeiros. Os servicos incluem informacao, preparacao de documentacao e orientacao em processos de disputa.' },
        { h2: '2. Taxas', content: 'Taxa de avaliacao: EUR 50 (nao reembolsavel). Taxa de sucesso: 20% (casos standard) ou 25% (casos complexos) do valor recuperado. Sem recuperacao, sem taxa de sucesso.' },
        { h2: '3. Processo', content: 'Apos a avaliacao inicial, a MRIntelligence determinara a viabilidade do caso. Se viavel, preparara a documentacao e submetera o processo. O cliente sera informado de cada etapa.' },
        { h2: '4. Obrigacoes do Cliente', content: 'O cliente deve fornecer toda a documentacao verdadeira e completa, responder prontamente a pedidos de informacao e autorizar a MRIntelligence a agir em seu nome.' },
        { h2: '5. Limitacao de Responsabilidade', content: 'A MRIntelligence nao garante a recuperacao de fundos em nenhum caso. A responsabilidade maxima e limitada ao valor das taxas pagas pelo cliente.' },
        { h2: '6. Resolucao de Litigios', content: 'Para clientes em Portugal: tribunais de Lisboa. Para outros: lei aplicavel do pais de residencia do cliente. Alternativamente: DECO (decoprotesto.pt).' }
      ]
    },
    cookieBanner: {
      text: 'Utilizamos cookies essenciais e analiticos para melhorar a sua experiencia.',
      accept: 'Aceitar', decline: 'Recusar', privacyLink: 'Politica de Privacidade'
    }
  },

  es: {
    langCode: 'es', htmlLang: 'es-ES', locale: 'es_ES',
    metaDesc: 'MRIntelligence — Expertos en recuperacion de fondos de transacciones fraudulentas. Portugal, Espana, Dinamarca, Italia. Sin recuperacion, sin cuota.',
    nav: { services: 'Servicios', howItWorks: 'Como Funciona', pricing: 'Precios', faq: 'FAQ', contact: 'Contacto' },
    hero: {
      badge: 'Expertos en Recuperacion de Fondos',
      h1: 'Recupere Su Dinero de Transacciones Fraudulentas',
      subtitle: 'La primera consultoria europea especializada en recuperacion de chargebacks para consumidores. Operamos en Portugal, Espana, Dinamarca e Italia con un modelo de cuota de exito.',
      ctaStart: 'Iniciar Recuperacion', ctaHow: 'Como Funciona',
      trust1: 'Sin Recuperacion, Sin Cuota', trust2: 'Conforme RGPD', trust3: '100% Espanol',
      stats: { label1: 'Casos Resueltos', val1: '1.240+', label2: 'Tasa de Exito', val2: '87%', label3: 'Recuperacion Media', val3: 'EUR 4.500' }
    },
    services: {
      title: 'Nuestros Servicios', subtitle: 'Soluciones especializadas para cada tipo de disputa financiera',
      items: [
        { title: 'Chargebacks Bancarios', desc: 'Gestion completa del proceso de chargeback con su banco. Documentacion, seguimiento y negociacion hasta la recuperacion total.' },
        { title: 'Disputas de Juego Online', desc: 'Especialistas en disputas contra operadores de juego online licenciados por la DGOJ y otras autoridades europeas.' },
        { title: 'Recuperacion de Fraude Online', desc: 'Recuperacion de fondos perdidos en esquemas de fraude online, inversiones falsas y phishing financiero.' },
        { title: 'Suscripciones Abusivas', desc: 'Cancelacion y recuperacion de valores cobrados indebidamente por suscripciones ocultas y servicios no solicitados.' },
        { title: 'Fraude en Turismo', desc: 'Recuperacion de pagos por reservas falsas, alojamientos inexistentes y servicios turisticos no prestados.' },
        { title: 'Documentacion Legal', desc: 'Preparacion profesional de toda la documentacion necesaria para la presentacion eficaz de su reclamacion.' }
      ]
    },
    process: {
      title: 'Como Funciona', steps: [
        { num: '01', title: 'Evaluacion Gratuita', desc: 'Complete el formulario con los detalles de su caso. Evaluamos gratuitamente la viabilidad de la recuperacion.' },
        { num: '02', title: 'Analisis de Viabilidad', desc: 'Nuestro equipo analiza la documentacion, transacciones y plazos legales aplicables a su caso especifico.' },
        { num: '03', title: 'Preparacion y Presentacion', desc: 'Elaboramos toda la documentacion necesaria y presentamos el proceso ante las entidades competentes.' },
        { num: '04', title: 'Recuperacion', desc: 'Acompanamos todo el proceso hasta la recuperacion de sus fondos. Pague solo cuando recupere.' }
      ]
    },
    pricing: {
      title: 'Precios Transparentes', subtitle: 'Sin costos ocultos. Pague solo por la evaluacion inicial y un porcentaje solo si recuperamos su dinero.',
      tiers: [
        { name: 'Evaluacion', price: 'EUR 50', unit: 'tarifa unica', desc: 'Analisis inicial completo de su caso y dictamen de viabilidad.', featured: false, features: ['Analisis detallado del caso', 'Dictamen de viabilidad', 'Plan de recuperacion', 'Respuesta en 48h'] },
        { name: 'Recuperacion Standard', price: '20%', unit: 'del monto recuperado', desc: 'Nuestra opcion mas popular para la mayoria de los casos de chargeback y fraude.', featured: true, features: ['Toda la documentacion incluida', 'Presentacion y seguimiento', 'Comunicacion con entidades', 'Pague solo si recupera'] },
        { name: 'Casos Complejos', price: '25%', unit: 'del monto recuperado', desc: 'Para casos judiciales, montos elevados o situaciones que requieren estrategia avanzada.', featured: false, features: ['Estrategia personalizada', 'Documentacion legal avanzada', 'Seguimiento judicial', 'Prioridad maxima'] }
      ]
    },
    testimonials: {
      title: 'Lo Que Dicen Nuestros Clientes',
      items: [
        { name: 'Javier L.', loc: 'Madrid', text: 'Recupere EUR 4.500 de una estafa de inversión. El proceso fue claro y transparente. Excelente servicio.', amount: 'EUR 4.500' },
        { name: 'Maria R.', loc: 'Barcelona', text: 'Pensaba que el dinero estaba perdido. MRIntelligence recupero todo en dos meses. Muy profesionales.', amount: '' },
        { name: 'Antonio G.', loc: 'Valencia', text: 'Gran equipo. Mantienen informado en cada paso y no hay costos ocultos. Totalmente recomendable.', amount: '' }
      ]
    },
    faq: {
      title: 'Preguntas Frecuentes',
      items: [
        { q: 'Cuanto tiempo tarda la recuperacion?', a: 'El plazo medio es de 30 a 90 dias, dependiendo del tipo de caso y complejidad. Los casos simples de chargeback se resuelven en 30-45 dias, mientras que los casos judiciales pueden tardar 3-6 meses.' },
        { q: 'Tengo que pagar por adelantado?', a: 'Solo la tarifa de evaluación de EUR 50 se paga por adelantado. La tarifa de exito solo se cobra tras la recuperacion efectiva de los fondos. Sin recuperacion, sin tarifa adicional.' },
        { q: 'Que tipos de casos aceptan?', a: 'Aceptamos chargebacks bancarios, disputas de juego online, fraudes de e-commerce, suscripciones abusivas, fraudes turisticos y otras transacciones no autorizadas. Evaluamos cada caso individualmente.' },
        { q: 'Mis datos estan seguros?', a: 'Si. Somos totalmente conformes con el RGPD. Todos los datos estan encriptados con AES-256, transmitidos via SSL/TLS y accesibles solo por personal autorizado. Nunca compartimos datos con terceros sin consentimiento.' },
        { q: 'Transacciones antiguas pueden recuperarse?', a: 'Depende del plazo legal aplicable. En Espana, el plazo para chargebacks es generalmente de 540 dias tras la transaccion. Para otros tipos de disputa, los plazos varian. Contactenos para evaluacion especifica.' },
        { q: 'Aceptan clientes de otros paises?', a: 'Si. Operamos en Portugal, Espana, Dinamarca e Italia. Para clientes de otros paises de la UE, evaluamos caso por caso segun la jurisdiccion aplicable.' }
      ]
    },
    contact: {
      title: 'Contactenos', email: 'es@mrintelligence.eu', phone: '+34 91 123 4567',
      address: 'MRIntelligence, Gran Via 50, 28013 Madrid, Espana',
      hours: 'Lun - Vie: 09:00 - 18:00 (CET)',
      formName: 'Nombre completo', formEmail: 'Email', formPhone: 'Telefono',
      formCase: 'Tipo de caso', formAmount: 'Valor (EUR)', formDesc: 'Descripcion del caso',
      formGdpr: 'Confirmo que he leido y acepto la Politica de Privacidad y autorizo el tratamiento de mis datos personales para fines de evaluacion del caso, de conformidad con el RGPD.',
      submit: 'Enviar Solicitud',
      cases: ['Chargeback bancario', 'Fraude online', 'Juego online', 'Suscripcion abusiva', 'Fraude turistico', 'Otro']
    },
    footer: {
      disclaimer: 'MRIntelligence es una consultoria de gestion. No somos una institucion financiera ni prestamos servicios juridicos regulamentados. Los servicios consisten en informacion, preparacion de documentacion y orientacion en procesos de disputa.',
      col1: 'MRIntelligence — Expertos en recuperacion de fondos para consumidores en Europa.',
      col2: 'Servicios\nChargeback\nFraude Online\nJuego Online\nSuscripciones\nTurismo',
      col3: 'Legal\nPolitica de Privacidad\nTerminos de Servicio\nPolitica de Cookies',
      col4: 'Contacto\nes@mrintelligence.eu\n+34 91 123 4567\nMadrid, Espana',
      copyright: '2026 MRIntelligence. Todos los derechos reservados.'
    },
    privacy: {
      title: 'Politica de Privacidad', updated: 'Actualizado: 7 de mayo de 2026',
      sections: [
        { h2: '1. Responsable del Tratamiento', content: 'MRIntelligence, con sede en Madrid, Espana, es responsable del tratamiento de datos personales conforme al RGPD. Email: privacy-es@mrintelligence.eu' },
        { h2: '2. Datos que recopilamos', content: 'Datos de identidad (nombre, DNI/pasaporte), contacto (email, telefono), datos financieros (detalles de transaccion, importe), datos del caso (descripcion, documentacion adjunta) y datos tecnicos (IP, cookies).' },
        { h2: '3. Base legal', content: 'Art. 6(1)(a) — Consentimiento; (b) — Ejecucion de contrato; (c) — Obligacion legal; (f) — Intereses legitimos (prevencion de fraude).' },
        { h2: '4. Derechos del titular', content: 'Derecho de acceso, rectificacion, supresion, limitacion, portabilidad y oposicion (Art. 15-21 RGPD). Contacto: privacy-es@mrintelligence.eu' },
        { h2: '5. Plazo de conservacion', content: 'Casos activos: 6 anos tras el cierre. Casos rechazados: 2 anos. Datos de contacto para marketing: hasta revocacion del consentimiento.' },
        { h2: '6. Seguridad', content: 'Encriptacion AES-256, SSL/TLS, acceso basado en roles, copias de seguridad diarias, auditorias trimestrales.' },
        { h2: '7. Terceros', content: 'Stripe (pagos), proveedor de email (Mailgun/Postmark), hosting cloud (AWS UE), analiticas (Matomo, autoalojado).' },
        { h2: '8. Reclamaciones', content: 'AEPD — Agencia Espanola de Proteccion de Datos: www.aepd.es' }
      ]
    },
    terms: {
      title: 'Terminos de Servicio', updated: 'Actualizado: 7 de mayo de 2026',
      sections: [
        { h2: '1. Naturaleza de los Servicios', content: 'MRIntelligence presta servicios de consultoria de gestion, no servicios juridicos regulados ni servicios financieros. Los servicios incluyen informacion, preparacion de documentacion y orientacion en procesos de disputa.' },
        { h2: '2. Tarifas', content: 'Tarifa de evaluacion: EUR 50 (no reembolsable). Tarifa de exito: 20% (casos standard) o 25% (casos complejos) del monto recuperado. Sin recuperacion, sin tarifa de exito.' },
        { h2: '3. Proceso', content: 'Tras la evaluacion inicial, MRIntelligence determinara la viabilidad del caso. Si es viable, preparara la documentacion y presentara el proceso. El cliente sera informado de cada etapa.' },
        { h2: '4. Obligaciones del Cliente', content: 'El cliente debe proporcionar toda la documentacion verdadera y completa, responder con prontitud a solicitudes de informacion y autorizar a MRIntelligence a actuar en su nombre.' },
        { h2: '5. Limitacion de Responsabilidad', content: 'MRIntelligence no garantiza la recuperacion de fondos en ningun caso. La responsabilidad maxima se limita al importe de las tarifas pagadas por el cliente.' },
        { h2: '6. Resolucion de Disputas', content: 'Para clientes en Espana: tribunales de Madrid. Para otros: ley aplicable del pais de residencia del cliente. Alternativamente: FACUA (facua.es).' }
      ]
    },
    cookieBanner: {
      text: 'Utilizamos cookies esenciales y analiticas para mejorar su experiencia.',
      accept: 'Aceptar', decline: 'Rechazar', privacyLink: 'Politica de Privacidad'
    }
  },

  dk: {
    langCode: 'dk', htmlLang: 'da-DK', locale: 'da_DK',
    metaDesc: 'MRIntelligence — Eksperter i genopretning af midler fra svigagtige transaktioner. Portugal, Spanien, Danmark, Italien. Ingen genopretning, intet gebyr.',
    nav: { services: 'Ydelser', howItWorks: 'Sadan Virker Det', pricing: 'Priser', faq: 'FAQ', contact: 'Kontakt' },
    hero: {
      badge: 'Eksperter i Genopretning af Midler',
      h1: 'Genvind Dine Penge fra Svigagtige Transaktioner',
      subtitle: 'Det forste europaeiske konsulentfirma specialiseret i chargeback-genopretning for forbrugere. Vi opererer i Portugal, Spanien, Danmark og Italien med en success-gebyr model.',
      ctaStart: 'Start Genopretning', ctaHow: 'Sadan Virker Det',
      trust1: 'Ingen Genopretning, Intet Gebyr', trust2: 'GDPR-compliant', trust3: '100% Dansk',
      stats: { label1: 'Oplaeste Sager', val1: '1.240+', label2: 'Successrate', val2: '87%', label3: 'Gennemsnitlig Genopretning', val3: '18.500 kr' }
    },
    services: {
      title: 'Vores Ydelser', subtitle: 'Specialiserede losninger til enhver type finansiel tvist',
      items: [
        { title: 'Bank Chargebacks', desc: 'Komplet handtering af chargeback-processen med din bank. Dokumentation, opfolgning og forhandling indtil fuld genopretning.' },
        { title: 'Online Spil Tvister', desc: 'Specialister i tvister mod online spiloperaterer licenseret af Spillemyndigheden og andre europaeiske myndigheder.' },
        { title: 'Online Svindel Genopretning', desc: 'Genopretning af midler mistet i online svindelordninger, falske investeringer og finansiel phishing.' },
        { title: 'Abonnement Svindel', desc: 'Opsigelse og genopretning af uberettigede gebyrer fra skjulte abonnementer og uanmodede tjenester.' },
        { title: 'Turisme Svindel', desc: 'Genopretning af betalinger for falske reservationer, ikke-eksisterende overnatning og uudforte turisttjenester.' },
        { title: 'Juridisk Dokumentation', desc: 'Professionel udarbejdelse af al nodvendig dokumentation til effektiv indgivelse af din klage.' }
      ]
    },
    process: {
      title: 'Sadan Virker Det', steps: [
        { num: '01', title: 'Gratis Vurdering', desc: 'Udfyld formularen med detaljer om din sag. Vi vurderer gratis genopretningsmulighederne.' },
        { num: '02', title: 'Levedygtighedsanalyse', desc: 'Vores team analyserer dokumentation, transaktioner og gaeldende juridiske frister for din specifikke sag.' },
        { num: '03', title: 'Forberedelse & Indgivelse', desc: 'Vi udarbejder al nodvendig dokumentation og indgiver sagen hos de kompetente myndigheder.' },
        { num: '04', title: 'Genopretning', desc: 'Vi folger hele processen indtil genopretning af dine midler. Du betaler kun nar du genvinder.' }
      ]
    },
    pricing: {
      title: 'Gennemsigtige Priser', subtitle: 'Ingen skjulte omkostninger. Betal kun for den indledende vurdering og en procentdel kun hvis vi genopretter dine penge.',
      tiers: [
        { name: 'Vurdering', price: '350 kr', unit: 'engangsgebyr', desc: 'Komplet indledende analyse af din sag og levedygtighedsrapport.', featured: false, features: ['Detaljeret sagsanalyse', 'Levedygtighedsrapport', 'Genopretningsplan', 'Svar inden for 48 timer'] },
        { name: 'Standard Genopretning', price: '20%', unit: 'af genoprettet belob', desc: 'Vores mest populare mulighed for de fleste chargeback- og svindelsager.', featured: true, features: ['Al dokumentation inkluderet', 'Indgivelse og opfolgning', 'Kommunikation med myndigheder', 'Betal kun hvis du genvinder'] },
        { name: 'Komplekse Sager', price: '25%', unit: 'af genoprettet belob', desc: 'For retssager, hoje belob eller situationer der kraever avanceret strategi.', featured: false, features: ['Personlig strategi', 'Avanceret juridisk dokumentation', 'Retlig opfolgning', 'Maksimal prioritet'] }
      ]
    },
    testimonials: {
      title: 'Hvad Vores Klienter Siger',
      items: [
        { name: 'Lars N.', loc: 'Kobenhavn', text: 'Genvandt 18.500 kr fra en falsk investering. Processen var klar og gennemsigtig. Fremragende service.', amount: '18.500 kr' },
        { name: 'Mette P.', loc: 'Aarhus', text: 'Troede pengene var vaek. MRIntelligence genoprettede alt pa under tre maneder. Meget professionelle.', amount: '' },
        { name: 'Jens K.', loc: 'Odense', text: 'Fremragende hold. Holder dig informeret pa hvert trin og ingen skjulte omkostninger. Helt anbefalelsesvaerdig.', amount: '' }
      ]
    },
    faq: {
      title: 'Ofte Stillede Sporgsmal',
      items: [
        { q: 'Hvor lang tid tager genopretning?', a: 'Den gennemsnitlige varighed er 30 til 90 dage, afhaengigt af sagstype og kompleksitet. Simple chargeback-sager loses pa 30-45 dage, mens retssager kan tage 3-6 maneder.' },
        { q: 'Skal jeg betale pa forhand?', a: 'Kun vurderingsgebyret pa 350 kr betales pa forhand. Success-gebyret opkraeves kun efter faktisk genopretning af midler. Ingen genopretning, intet yderligere gebyr.' },
        { q: 'Hvilke sagstyper accepterer I?', a: 'Vi accepterer bank chargebacks, online spil tvister, e-commerce svindel, abonnement svindel, turisme svindel og andre uautoriserede transaktioner. Vi vurderer hver sag individuelt.' },
        { q: 'Er mine data sikre?', a: 'Ja. Vi er fuldt GDPR-compliant. Alle data er krypteret med AES-256, transmitteret via SSL/TLS og kun tilgaengeligt for autoriseret personale. Vi deler aldrig data med tredjeparter uden samtykke.' },
        { q: 'Kan gamle transaktioner genoprettes?', a: 'Det afhaenger af den gaeldende juridiske frist. I Danmark er chargeback-fristen typisk 540 dage efter transaktionen. For andre tvistetyper varierer fristerne. Kontakt os for specifik vurdering.' },
        { q: 'Accepterer I klienter fra andre lande?', a: 'Ja. Vi opererer i Portugal, Spanien, Danmark og Italien. For klienter fra andre EU-lande vurderer vi sag for sag efter gaeldende jurisdiktion.' }
      ]
    },
    contact: {
      title: 'Kontakt Os', email: 'dk@mrintelligence.eu', phone: '+45 70 12 34 56',
      address: 'MRIntelligence, Bredgade 40, 1260 Kobenhavn K, Danmark',
      hours: 'Man - Fre: 09:00 - 18:00 (CET)',
      formName: 'Fulde navn', formEmail: 'Email', formPhone: 'Telefon',
      formCase: 'Sagstype', formAmount: 'Belob (kr)', formDesc: 'Sagsbeskrivelse',
      formGdpr: 'Jeg bekraefter, at jeg har laest og accepterer Privatlivspolitikken og giver samtykke til behandling af mine personoplysninger til sagsvurdering i overensstemmelse med GDPR.',
      submit: 'Send Anmodning',
      cases: ['Bank chargeback', 'Online svindel', 'Spil online', 'Abonnement svindel', 'Turisme svindel', 'Andet']
    },
    footer: {
      disclaimer: 'MRIntelligence er et management konsulentfirma. Vi er ikke en finansiel institution og yder ikke regulerede juridiske tjenester. Tjenesterne bestar af information, dokumentationsforberedelse og vejledning i tvistprocesser.',
      col1: 'MRIntelligence — Eksperter i genopretning af midler for forbrugere i Europa.',
      col2: 'Ydelser\nChargeback\nOnline Svindel\nSpil Online\nAbonnementer\nTurisme',
      col3: 'Juridisk\nPrivatlivspolitik\nVilkar\nCookiepolitik',
      col4: 'Kontakt\ndk@mrintelligence.eu\n+45 70 12 34 56\nKobenhavn, Danmark',
      copyright: '2026 MRIntelligence. Alle rettigheder forbeholdes.'
    },
    privacy: {
      title: 'Privatlivspolitik', updated: 'Opdateret: 7. maj 2026',
      sections: [
        { h2: '1. Dataansvarlig', content: 'MRIntelligence, med adresse i Kobenhavn, Danmark, er dataansvarlig i henhold til GDPR. Email: privacy-dk@mrintelligence.eu' },
        { h2: '2. Data vi indsamler', content: 'Identitetsdata (navn, CPR/pass), kontaktdata (email, telefon), finansielle data (transaktionsdetaljer, belob), sagsdata (beskrivelse, vedhaeftet dokumentation) og tekniske data (IP, cookies).' },
        { h2: '3. Retlig grundlag', content: 'Art. 6(1)(a) — Samtykke; (b) — Kontraktudforelse; (c) — Retlig forpligtelse; (f) — Legitime interesser (svindelforebyggelse).' },
        { h2: '4. Dine rettigheder', content: 'Ret til adgang, berigtigelse, sletning, begraensning, dataportabilitet og indsigelse (Art. 15-21 GDPR). Kontakt: privacy-dk@mrintelligence.eu' },
        { h2: '5. Opbevaringsperiode', content: 'Aktive sager: 6 ar efter afslutning. Afviste sager: 2 ar. Kontaktdata til markedsforing: indtil samtykke tilbagekaldes.' },
        { h2: '6. Sikkerhed', content: 'AES-256 kryptering, SSL/TLS, rollebaseret adgang, daglige backups, kvartalsvise revisioner.' },
        { h2: '7. Tredjeparter', content: 'Stripe (betalinger), email-udbyder (Mailgun/Postmark), cloud-hosting (AWS EU), analytics (Matomo, selvhostet).' },
        { h2: '8. Klager', content: 'Datatilsynet — www.datatilsynet.dk' }
      ]
    },
    terms: {
      title: 'Vilkar for Service', updated: 'Opdateret: 7. maj 2026',
      sections: [
        { h2: '1. Tjenestens Karakter', content: 'MRIntelligence yder management konsulenttjenester, ikke regulerede juridiske tjenester eller finansielle tjenester. Tjenesterne omfatter information, dokumentationsforberedelse og vejledning i tvistprocesser.' },
        { h2: '2. Gebyrer', content: 'Vurderingsgebyr: 350 kr (ikke-refunderbart). Success-gebyr: 20% (standard sager) eller 25% (komplekse sager) af genoprettet belob. Ingen genopretning, intet success-gebyr.' },
        { h2: '3. Proces', content: 'Efter den indledende vurdering vil MRIntelligence fastsla sagens levedygtighed. Hvis levedygtig, forberedes dokumentation og sagen indgives. Klienten informeres om hvert trin.' },
        { h2: '4. Klientens Forpligtelser', content: 'Klienten skal levere al dokumentation sand og fuldstaendig, svare rettidigt pa anmodninger om information og godkende MRIntelligence til at handle pa deres vegne.' },
        { h2: '5. Ansvarsbegraensning', content: 'MRIntelligence garanterer ikke genopretning af midler i nogen sag. Maksimalt ansvar er begraenset til de gebyrer klienten har betalt.' },
        { h2: '6. Tvistlosning', content: 'For klienter i Danmark: domstolene i Kobenhavn. For andre: gaeldende lov i klientens bopaeldsland. Alternativt: Forbrugerombudsmanden (forbrugerombudsmanden.dk).' }
      ]
    },
    cookieBanner: {
      text: 'Vi bruger essentielle og analytiske cookies for at forbedre din oplevelse.',
      accept: 'Accepter', decline: 'Afvis', privacyLink: 'Privatlivspolitik'
    }
  },

  it: {
    langCode: 'it', htmlLang: 'it-IT', locale: 'it_IT',
    metaDesc: 'MRIntelligence — Esperti nel recupero di fondi da transazioni fraudolente. Portogallo, Spagna, Danimarca, Italia. Nessun recupero, nessuna commissione.',
    nav: { services: 'Servizi', howItWorks: 'Come Funziona', pricing: 'Prezzi', faq: 'FAQ', contact: 'Contatto' },
    hero: {
      badge: 'Esperti nel Recupero di Fondi',
      h1: 'Recupera i Tuoi Soldi dalle Transazioni Fraudolente',
      subtitle: 'La prima consulenza europea specializzata nel recupero di chargeback per consumatori. Operiamo in Portogallo, Spagna, Danimarca e Italia con un modello di commissione di successo.',
      ctaStart: 'Inizia il Recupero', ctaHow: 'Come Funziona',
      trust1: 'Nessun Recupero, Nessuna Commissione', trust2: 'GDPR Compliant', trust3: '100% Italiano',
      stats: { label1: 'Casi Risolti', val1: '1.240+', label2: 'Tasso di Successo', val2: '87%', label3: 'Recupero Medio', val3: 'EUR 3.800' }
    },
    services: {
      title: 'I Nostri Servizi', subtitle: 'Soluzioni specializzate per ogni tipo di disputa finanziaria',
      items: [
        { title: 'Chargeback Bancari', desc: 'Gestione completa del processo di chargeback con la tua banca. Documentazione, follow-up e negoziazione fino al recupero totale.' },
        { title: 'Dispute sul Gioco Online', desc: 'Specialisti in dispute contro operatori di gioco online autorizzati dall\'ADM e da altre autorita europee.' },
        { title: 'Recupero Frodi Online', desc: 'Recupero di fondi persi in schemi di frode online, investimenti falsi e phishing finanziario.' },
        { title: 'Sottoscrizioni Abusive', desc: 'Cancellazione e recupero di valori addebitati ingiustamente per sottoscrizioni nascoste e servizi non richiesti.' },
        { title: 'Frode nel Turismo', desc: 'Recupero di pagamenti per prenotazioni false, alloggi inesistenti e servizi turistici non prestati.' },
        { title: 'Documentazione Legale', desc: 'Preparazione professionale di tutta la documentazione necessaria per la presentazione efficace del tuo reclamo.' }
      ]
    },
    process: {
      title: 'Come Funziona', steps: [
        { num: '01', title: 'Valutazione Gratuita', desc: 'Compila il modulo con i dettagli del tuo caso. Valutiamo gratuitamente la fattibilita del recupero.' },
        { num: '02', title: 'Analisi di Fattibilita', desc: 'Il nostro team analizza documentazione, transazioni e scadenze legali applicabili al tuo caso specifico.' },
        { num: '03', title: 'Preparazione e Presentazione', desc: 'Elaboriamo tutta la documentazione necessaria e presentiamo il processo alle autorita competenti.' },
        { num: '04', title: 'Recupero', desc: 'Seguiamo l\'intero processo fino al recupero dei tuoi fondi. Paghi solo quando recuperi.' }
      ]
    },
    pricing: {
      title: 'Prezzi Trasparenti', subtitle: 'Nessun costo nascosto. Paga solo per la valutazione iniziale e una percentuale solo se recuperiamo i tuoi soldi.',
      tiers: [
        { name: 'Valutazione', price: 'EUR 50', unit: 'tariffa unica', desc: 'Analisi iniziale completa del tuo caso e parere di fattibilita.', featured: false, features: ['Analisi dettagliata del caso', 'Parere di fattibilita', 'Piano di recupero', 'Risposta in 48h'] },
        { name: 'Recupero Standard', price: '20%', unit: 'dell\'importo recuperato', desc: 'La nostra opzione piu popolare per la maggior parte dei casi di chargeback e frode.', featured: true, features: ['Tutta la documentazione inclusa', 'Presentazione e follow-up', 'Comunicazione con entita', 'Paghi solo se recuperi'] },
        { name: 'Casi Complessi', price: '25%', unit: 'dell\'importo recuperato', desc: 'Per casi giudiziari, importi elevati o situazioni che richiedono strategia avanzata.', featured: false, features: ['Strategia personalizzata', 'Documentazione legale avanzata', 'Assistenza giudiziaria', 'Priorita massima'] }
      ]
    },
    testimonials: {
      title: 'Cosa Dicono i Nostri Clienti',
      items: [
        { name: 'Marco B.', loc: 'Milano', text: 'Ho recuperato EUR 4.200 da una truffa di investimento. Il processo e stato chiaro e trasparente. Eccellente servizio.', amount: 'EUR 4.200' },
        { name: 'Laura M.', loc: 'Roma', text: 'Pensavo i soldi fossero persi. MRIntelligence ha recuperato tutto in due mesi. Professionisti eccezionali.', amount: '' },
        { name: 'Giuseppe R.', loc: 'Napoli', text: 'Servizio impeccabile. Il team spiega ogni passo e non ci sono costi nascosti. Consigliatissimo.', amount: '' }
      ]
    },
    faq: {
      title: 'Domande Frequenti',
      items: [
        { q: 'Quanto tempo dura il recupero?', a: 'Il termine medio e di 30 a 90 giorni, a seconda del tipo di caso e della complessita. I casi semplici di chargeback si risolvono in 30-45 giorni, mentre i casi giudiziari possono richiedere 3-6 mesi.' },
        { q: 'Devo pagare in anticipo?', a: 'Solo la tariffa di valutazione di EUR 50 viene pagata in anticipo. La commissione di successo viene addebitata solo dopo il recupero effettivo dei fondi. Nessun recupero, nessuna commissione aggiuntiva.' },
        { q: 'Che tipi di casi accettate?', a: 'Accettiamo chargeback bancari, dispute sul gioco online, frodi di e-commerce, sottoscrizioni abusive, frodi turistiche e altre transazioni non autorizzate. Valutiamo ogni caso individualmente.' },
        { q: 'I miei dati sono al sicuro?', a: 'Si. Siamo pienamente conformi al GDPR. Tutti i dati sono crittografati con AES-256, trasmessi via SSL/TLS e accessibili solo al personale autorizzato. Non condividiamo mai dati con terze parti senza consenso.' },
        { q: 'Transazioni vecchie possono essere recuperate?', a: 'Dipende dalla scadenza legale applicabile. In Italia, il termine per i chargeback e generalmente di 540 giorni dalla transazione. Per altri tipi di dispute, i termini variano. Contattaci per valutazione specifica.' },
        { q: 'Accettate clienti da altri paesi?', a: 'Si. Operiamo in Portogallo, Spagna, Danimarca e Italia. Per clienti da altri paesi dell\'UE, valutiamo caso per caso secondo la giurisdizione applicabile.' }
      ]
    },
    contact: {
      title: 'Contattaci', email: 'it@mrintelligence.eu', phone: '+39 02 1234 5678',
      address: 'MRIntelligence, Via Roma 100, 20121 Milano, Italia',
      hours: 'Lun - Ven: 09:00 - 18:00 (CET)',
      formName: 'Nome completo', formEmail: 'Email', formPhone: 'Telefono',
      formCase: 'Tipo di caso', formAmount: 'Importo (EUR)', formDesc: 'Descrizione del caso',
      formGdpr: 'Confermo di aver letto e accettato l\'Informativa sulla Privacy e autorizzo il trattamento dei miei dati personali per la valutazione del caso, in conformita con il GDPR.',
      submit: 'Invia Richiesta',
      cases: ['Chargeback bancario', 'Frode online', 'Gioco online', 'Sottoscrizione abusiva', 'Frode turistica', 'Altro']
    },
    footer: {
      disclaimer: 'MRIntelligence e una societa di consulenza manageriale. Non siamo un istituto finanziario e non forniamo servizi legali regolamentati. I servizi consistono in informazione, preparazione di documentazione e orientamento nei processi di disputa.',
      col1: 'MRIntelligence — Esperti nel recupero di fondi per consumatori in Europa.',
      col2: 'Servizi\nChargeback\nFrode Online\nGioco Online\nSottoscrizioni\nTurismo',
      col3: 'Legale\nInformativa Privacy\nTermini di Servizio\nCookie Policy',
      col4: 'Contatto\nit@mrintelligence.eu\n+39 02 1234 5678\nMilano, Italia',
      copyright: '2026 MRIntelligence. Tutti i diritti riservati.'
    },
    privacy: {
      title: 'Informativa sulla Privacy', updated: 'Aggiornato: 7 maggio 2026',
      sections: [
        { h2: '1. Titolare del Trattamento', content: 'MRIntelligence, con sede a Milano, Italia, e titolare del trattamento dei dati personali ai sensi del GDPR. Email: privacy-it@mrintelligence.eu' },
        { h2: '2. Dati che raccogliamo', content: 'Dati di identita (nome, codice fiscale/passaporto), contatto (email, telefono), dati finanziari (dettagli transazione, importo), dati del caso (descrizione, documentazione allegata) e dati tecnici (IP, cookies).' },
        { h2: '3. Base giuridica', content: 'Art. 6(1)(a) — Consenso; (b) — Esecuzione contratto; (c) — Obbligo legale; (f) — Interessi legittimi (prevenzione frodi).' },
        { h2: '4. Diritti dell\'interessato', content: 'Diritto di accesso, retifica, cancellazione, limitazione, portabilita e opposizione (Art. 15-21 GDPR). Contatto: privacy-it@mrintelligence.eu' },
        { h2: '5. Periodo di conservazione', content: 'Casi attivi: 6 anni dalla chiusura. Casi rifiutati: 2 anni. Dati contatto marketing: fino a revoca consenso.' },
        { h2: '6. Sicurezza', content: 'Crittografia AES-256, SSL/TLS, accesso basato su ruoli, backup giornalieri, audit trimestrali.' },
        { h2: '7. Terze parti', content: 'Stripe (pagamenti), provider email (Mailgun/Postmark), hosting cloud (AWS UE), analytics (Matomo, self-hosted).' },
        { h2: '8. Reclami', content: 'Garante per la Protezione dei Dati Personali (Italia): www.garanteprivacy.it' }
      ]
    },
    terms: {
      title: 'Termini di Servizio', updated: 'Aggiornato: 7 maggio 2026',
      sections: [
        { h2: '1. Natura dei Servizi', content: 'MRIntelligence fornisce servizi di consulenza manageriale, non servizi legali regolamentati ne servizi finanziari. I servizi includono informazione, preparazione documentazione e orientamento nei processi di disputa.' },
        { h2: '2. Tariffe', content: 'Tariffa di valutazione: EUR 50 (non rimborsabile). Commissione di successo: 20% (casi standard) o 25% (casi complessi) dell\'importo recuperato. Nessun recupero, nessuna commissione.' },
        { h2: '3. Processo', content: 'Dopo la valutazione iniziale, MRIntelligence determinera la fattibilita del caso. Se fattibile, preparera la documentazione e presentera il processo. Il cliente sara informato di ogni fase.' },
        { h2: '4. Obblighi del Cliente', content: 'Il cliente deve fornire tutta la documentazione vera e completa, rispondere tempestivamente alle richieste di informazione e autorizzare MRIntelligence ad agire per suo conto.' },
        { h2: '5. Limitazione di Responsabilita', content: 'MRIntelligence non garantisce il recupero di fondi in alcun caso. La responsabilita massima e limitata all\'importo delle tariffe pagate dal cliente.' },
        { h2: '6. Risoluzione Controversie', content: 'Per clienti in Italia: tribunali di Milano. Per altri: legge applicabile del paese di residenza del cliente. Alternativamente: conciliazione tramite ADR.' }
      ]
    },
    cookieBanner: {
      text: 'Utilizziamo cookie essenziali e analitici per migliorare la tua esperienza.',
      accept: 'Accetta', decline: 'Rifiuta', privacyLink: 'Informativa Privacy'
    }
  },

  en: {
    langCode: 'en', htmlLang: 'en', locale: 'en_US',
    metaDesc: 'MRIntelligence — Fund recovery experts for fraudulent transactions. Portugal, Spain, Denmark, Italy. No recovery, no fee.',
    nav: { services: 'Services', howItWorks: 'How It Works', pricing: 'Pricing', faq: 'FAQ', contact: 'Contact' },
    hero: {
      badge: 'Fund Recovery Experts',
      h1: 'Recover Your Money from Fraudulent Transactions',
      subtitle: 'The first European consultancy specialized in consumer chargeback recovery. We operate in Portugal, Spain, Denmark and Italy on a success-fee basis.',
      ctaStart: 'Start Recovery', ctaHow: 'How It Works',
      trust1: 'No Recovery, No Fee', trust2: 'GDPR Compliant', trust3: '100% European',
      stats: { label1: 'Cases Resolved', val1: '1.240+', label2: 'Success Rate', val2: '87%', label3: 'Average Recovery', val3: 'EUR 3.500' }
    },
    services: {
      title: 'Our Services', subtitle: 'Specialized solutions for every type of financial dispute',
      items: [
        { title: 'Bank Chargebacks', desc: 'Complete management of the chargeback process with your bank. Documentation, follow-up and negotiation until full recovery.' },
        { title: 'Online Gambling Disputes', desc: 'Specialists in disputes against licensed online gambling operators across European regulatory authorities.' },
        { title: 'Online Fraud Recovery', desc: 'Recovery of funds lost to online fraud schemes, fake investments and financial phishing.' },
        { title: 'Abusive Subscriptions', desc: 'Cancellation and recovery of amounts wrongfully charged by hidden subscriptions and unsolicited services.' },
        { title: 'Tourism Fraud', desc: 'Recovery of payments for fake bookings, non-existent accommodation and unprovided tourist services.' },
        { title: 'Legal Documentation', desc: 'Professional preparation of all necessary documentation for effective submission of your claim.' }
      ]
    },
    process: {
      title: 'How It Works', steps: [
        { num: '01', title: 'Free Assessment', desc: 'Fill out the form with your case details. We assess recovery viability completely free of charge.' },
        { num: '02', title: 'Viability Analysis', desc: 'Our team analyses documentation, transactions and applicable legal deadlines for your specific case.' },
        { num: '03', title: 'Preparation & Submission', desc: 'We prepare all necessary documentation and submit the case to the competent authorities.' },
        { num: '04', title: 'Recovery', desc: 'We follow the entire process through to recovery of your funds. You only pay when you recover.' }
      ]
    },
    pricing: {
      title: 'Transparent Pricing', subtitle: 'No hidden costs. Pay only for the initial assessment and a percentage only if we recover your money.',
      tiers: [
        { name: 'Assessment', price: 'EUR 50 / GBP 45', unit: 'one-time fee', desc: 'Complete initial analysis of your case and viability assessment.', featured: false, features: ['Detailed case analysis', 'Viability assessment', 'Recovery plan', 'Response in 48h'] },
        { name: 'Standard Recovery', price: '20%', unit: 'of recovered amount', desc: 'Our most popular option for the majority of chargeback and fraud cases.', featured: true, features: ['All documentation included', 'Submission & follow-up', 'Communication with entities', 'Pay only if you recover'] },
        { name: 'Complex Cases', price: '25%', unit: 'of recovered amount', desc: 'For court cases, high-value amounts or situations requiring advanced strategy.', featured: false, features: ['Personalized strategy', 'Advanced legal documentation', 'Court follow-up', 'Maximum priority'] }
      ]
    },
    testimonials: {
      title: 'What Our Clients Say',
      items: [
        { name: 'James T.', loc: 'London', text: 'Recovered GBP 4,800 from a fake investment scheme. The process was clear and transparent throughout. Excellent service.', amount: 'GBP 4,800' },
        { name: 'Sophie L.', loc: 'Manchester', text: 'Thought the money was gone. MRIntelligence recovered everything within three months. True professionals.', amount: '' },
        { name: 'Robert K.', loc: 'Birmingham', text: 'Outstanding team. They keep you informed at every step and there are no hidden costs. Highly recommended.', amount: '' }
      ]
    },
    faq: {
      title: 'Frequently Asked Questions',
      items: [
        { q: 'How long does recovery take?', a: 'The average timeframe is 30 to 90 days, depending on case type and complexity. Simple chargeback cases resolve in 30-45 days, while court cases may take 3-6 months.' },
        { q: 'Do I pay upfront?', a: 'Only the EUR 50 / GBP 45 assessment fee is paid upfront. The success fee is only charged after actual recovery of funds. No recovery, no additional fee.' },
        { q: 'What case types do you accept?', a: 'We accept bank chargebacks, online gambling disputes, e-commerce fraud, abusive subscriptions, tourism fraud and other unauthorized transactions. We assess each case individually.' },
        { q: 'Are my data secure?', a: 'Yes. We are fully GDPR compliant. All data is encrypted with AES-256, transmitted via SSL/TLS and accessible only to authorised personnel. We never share data with third parties without consent.' },
        { q: 'Can old transactions be recovered?', a: 'It depends on the applicable legal deadline. Generally, the chargeback deadline is 540 days from the transaction. For other dispute types, deadlines vary. Contact us for specific assessment.' },
        { q: 'Do you accept clients from other countries?', a: 'Yes. We operate in Portugal, Spain, Denmark and Italy. For clients from other EU countries, we assess on a case-by-case basis according to applicable jurisdiction.' }
      ]
    },
    contact: {
      title: 'Contact Us', email: 'en@mrintelligence.eu', phone: '+44 20 7946 0958',
      address: 'MRIntelligence, 12 Finsbury Square, London EC2A 1BR, United Kingdom',
      hours: 'Mon - Fri: 09:00 - 18:00 (GMT/BST)',
      formName: 'Full name', formEmail: 'Email', formPhone: 'Phone',
      formCase: 'Case type', formAmount: 'Amount (EUR/GBP)', formDesc: 'Case description',
      formGdpr: 'I confirm I have read and accept the Privacy Policy and authorise processing of my personal data for case assessment purposes, in compliance with the GDPR.',
      submit: 'Submit Request',
      cases: ['Bank chargeback', 'Online fraud', 'Online gambling', 'Abusive subscription', 'Tourism fraud', 'Other']
    },
    footer: {
      disclaimer: 'MRIntelligence is a management consultancy. We are not a financial institution and do not provide regulated legal services. Services consist of information, documentation preparation, and guidance in dispute processes.',
      col1: 'MRIntelligence — Fund recovery experts for consumers across Europe.',
      col2: 'Services\nChargeback\nOnline Fraud\nGambling\nSubscriptions\nTourism',
      col3: 'Legal\nPrivacy Policy\nTerms of Service\nCookie Policy',
      col4: 'Contact\nen@mrintelligence.eu\n+44 20 7946 0958\nLondon, UK',
      copyright: '2026 MRIntelligence. All rights reserved.'
    },
    privacy: {
      title: 'Privacy Policy', updated: 'Updated: 7 May 2026',
      sections: [
        { h2: '1. Data Controller', content: 'MRIntelligence, operating from Cyprus, is the data controller under GDPR. Email: privacy-en@mrintelligence.eu' },
        { h2: '2. Data We Collect', content: 'Identity data (name, ID/passport), contact data (email, phone), financial data (transaction details, amount), case data (description, attached documentation) and technical data (IP, cookies).' },
        { h2: '3. Legal Basis', content: 'Art. 6(1)(a) — Consent; (b) — Contract performance; (c) — Legal obligation; (f) — Legitimate interests (fraud prevention).' },
        { h2: '4. Your Rights', content: 'Right of access, rectification, erasure, restriction, portability and objection (Art. 15-21 GDPR). Contact: privacy-en@mrintelligence.eu' },
        { h2: '5. Retention', content: 'Active cases: 6 years after closure. Declined cases: 2 years. Marketing contact data: until consent is withdrawn.' },
        { h2: '6. Security', content: 'AES-256 encryption, SSL/TLS, role-based access, daily backups, quarterly audits.' },
        { h2: '7. Third Parties', content: 'Stripe (payments), email provider (Mailgun/Postmark), cloud hosting (AWS EU), analytics (Matomo, self-hosted).' },
        { h2: '8. Complaints', content: 'ICO — Information Commissioner\'s Office (UK): www.ico.org.uk. EU residents may also complain to their local DPA.' }
      ]
    },
    terms: {
      title: 'Terms of Service', updated: 'Updated: 7 May 2026',
      sections: [
        { h2: '1. Nature of Services', content: 'MRIntelligence provides management consultancy services, not regulated legal services or financial services. Services include information, documentation preparation and guidance in dispute processes.' },
        { h2: '2. Fees', content: 'Assessment fee: EUR 50 / GBP 45 (non-refundable). Success fee: 20% (standard cases) or 25% (complex cases) of recovered amount. No recovery, no success fee.' },
        { h2: '3. Process', content: 'After initial assessment, MRIntelligence will determine case viability. If viable, we will prepare documentation and submit the case. The client will be informed at every stage.' },
        { h2: '4. Client Obligations', content: 'The client must provide all true and complete documentation, respond promptly to information requests, and authorise MRIntelligence to act on their behalf.' },
        { h2: '5. Limitation of Liability', content: 'MRIntelligence does not guarantee recovery of funds in any case. Maximum liability is limited to the amount of fees paid by the client.' },
        { h2: '6. Dispute Resolution', content: 'For UK clients: courts of England and Wales. For EU clients: applicable law of client\'s country of residence. ADR available through local ombudsman services.' }
      ]
    },
    cookieBanner: {
      text: 'We use essential and analytical cookies to improve your experience.',
      accept: 'Accept', decline: 'Decline', privacyLink: 'Privacy Policy'
    }
  }
};
