import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import type { Lang } from '../data/translations';
import { translations } from '../data/translations';

const flagMap: Record<Lang, string> = {
  pt: '🇵🇹', es: '🇪🇸', dk: '🇩🇰', it: '🇮🇹', en: '🇬🇧'
};

const langNames: Record<Lang, string> = {
  pt: 'Portugues', es: 'Espanol', dk: 'Dansk', it: 'Italiano', en: 'English'
};

export default function Navbar({ lang, onLangChange }: { lang: Lang; onLangChange: (l: Lang) => void }) {
  const t = translations[lang];
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);

  useEffect(() => { setMenuOpen(false); }, [location]);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) { el.scrollIntoView({ behavior: 'smooth' }); setMenuOpen(false); }
  };

  const langs: Lang[] = ['pt', 'es', 'dk', 'it', 'en'];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-[#0a0a0f]/95 backdrop-blur-md shadow-lg' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to={`/${lang}`} className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-[#c9a84c] flex items-center justify-center text-[#0a0a0f] font-bold text-lg">M</div>
          <span className="text-white font-semibold text-lg tracking-wide">MRIntelligence</span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden lg:flex items-center gap-8">
          <button onClick={() => scrollTo('services')} className="text-white/70 hover:text-[#c9a84c] text-sm font-medium transition-colors">{t.nav.services}</button>
          <button onClick={() => scrollTo('process')} className="text-white/70 hover:text-[#c9a84c] text-sm font-medium transition-colors">{t.nav.howItWorks}</button>
          <button onClick={() => scrollTo('pricing')} className="text-white/70 hover:text-[#c9a84c] text-sm font-medium transition-colors">{t.nav.pricing}</button>
          <button onClick={() => scrollTo('faq')} className="text-white/70 hover:text-[#c9a84c] text-sm font-medium transition-colors">{t.nav.faq}</button>
          <button onClick={() => scrollTo('contact')} className="text-white/70 hover:text-[#c9a84c] text-sm font-medium transition-colors">{t.nav.contact}</button>

          {/* Language dropdown */}
          <div className="relative">
            <button onClick={() => setLangOpen(!langOpen)} className="flex items-center gap-1.5 text-white/80 text-sm font-medium hover:text-[#c9a84c] transition-colors">
              <span className="text-base">{flagMap[lang]}</span>
              <span className="uppercase text-xs">{lang}</span>
              <svg width="10" height="6" viewBox="0 0 10 6" fill="none"><path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="1.5"/></svg>
            </button>
            {langOpen && (
              <div className="absolute top-full right-0 mt-2 bg-[#13131f] border border-white/10 rounded-xl shadow-2xl overflow-hidden min-w-[160px]">
                {langs.map((l) => (
                  <Link key={l} to={location.pathname.replace(`/${lang}`, `/${l}`)} onClick={() => { onLangChange(l); setLangOpen(false); }}
                    className={`flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-[#c9a84c]/10 transition-colors ${l === lang ? 'text-[#c9a84c]' : 'text-white/80'}`}>
                    <span className="text-base">{flagMap[l]}</span>
                    <span>{langNames[l]}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Mobile hamburger */}
        <button className="lg:hidden text-white" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="lg:hidden bg-[#0a0a0f]/98 backdrop-blur-md border-t border-white/10">
          <div className="px-6 py-6 flex flex-col gap-4">
            <button onClick={() => scrollTo('services')} className="text-white/80 text-left text-base">{t.nav.services}</button>
            <button onClick={() => scrollTo('process')} className="text-white/80 text-left text-base">{t.nav.howItWorks}</button>
            <button onClick={() => scrollTo('pricing')} className="text-white/80 text-left text-base">{t.nav.pricing}</button>
            <button onClick={() => scrollTo('faq')} className="text-white/80 text-left text-base">{t.nav.faq}</button>
            <button onClick={() => scrollTo('contact')} className="text-white/80 text-left text-base">{t.nav.contact}</button>
            <div className="flex flex-wrap gap-3 pt-2">
              {langs.map((l) => (
                <Link key={l} to={location.pathname.replace(`/${lang}`, `/${l}`)} onClick={() => onLangChange(l)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm border ${l === lang ? 'border-[#c9a84c] text-[#c9a84c]' : 'border-white/20 text-white/60'}`}>
                  <span>{flagMap[l]}</span><span className="uppercase">{l}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
