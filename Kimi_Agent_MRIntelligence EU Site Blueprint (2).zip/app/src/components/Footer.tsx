import { Link } from 'react-router-dom';
import type { Lang } from '../data/translations';
import { translations } from '../data/translations';

export default function Footer({ lang }: { lang: Lang }) {
  const t = translations[lang];
  const cols = t.footer;
  const col2 = cols.col2.split('\n');
  const col3 = cols.col3.split('\n');
  const col4 = cols.col4.split('\n');

  return (
    <footer className="bg-[#0a0a0f] border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6 pt-16 pb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-[#c9a84c] flex items-center justify-center text-[#0a0a0f] font-bold text-sm">M</div>
              <span className="text-white font-semibold">MRIntelligence</span>
            </div>
            <p className="text-white/50 text-sm leading-relaxed">{cols.col1}</p>
          </div>
          {/* Services */}
          <div>
            <h4 className="text-white font-semibold mb-4">{col2[0]}</h4>
            <ul className="space-y-2">
              {col2.slice(1).map((item, i) => (
                <li key={i}><span className="text-white/50 text-sm hover:text-[#c9a84c] cursor-pointer transition-colors">{item}</span></li>
              ))}
            </ul>
          </div>
          {/* Legal */}
          <div>
            <h4 className="text-white font-semibold mb-4">{col3[0]}</h4>
            <ul className="space-y-2">
              <li><Link to={`/${lang}/privacy`} className="text-white/50 text-sm hover:text-[#c9a84c] transition-colors">{col3[1]}</Link></li>
              <li><Link to={`/${lang}/terms`} className="text-white/50 text-sm hover:text-[#c9a84c] transition-colors">{col3[2]}</Link></li>
              <li><span className="text-white/50 text-sm">{col3[3]}</span></li>
            </ul>
          </div>
          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">{col4[0]}</h4>
            <ul className="space-y-2">
              {col4.slice(1).map((item, i) => (
                <li key={i}><span className="text-white/50 text-sm">{item}</span></li>
              ))}
            </ul>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-12 pt-8 border-t border-white/10">
          <p className="text-white/30 text-xs leading-relaxed max-w-4xl">{cols.disclaimer}</p>
          <p className="text-white/20 text-xs mt-4">&copy; {cols.copyright}</p>
        </div>
      </div>
    </footer>
  );
}
