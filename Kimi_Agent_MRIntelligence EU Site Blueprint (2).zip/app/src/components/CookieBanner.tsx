import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import type { Lang } from '../data/translations';
import { translations } from '../data/translations';

export default function CookieBanner({ lang }: { lang: Lang }) {
  const t = translations[lang];
  const [show, setShow] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!localStorage.getItem('mr_cookie_consent')) setShow(true);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleChoice = (choice: string) => {
    localStorage.setItem('mr_cookie_consent', choice);
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#13131f]/95 backdrop-blur-md border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-white/80 text-sm text-center sm:text-left">{t.cookieBanner.text}</p>
        <div className="flex items-center gap-3">
          <Link to={`/${lang}/privacy`} className="text-[#c9a84c] text-sm hover:underline">{t.cookieBanner.privacyLink}</Link>
          <button onClick={() => handleChoice('declined')} className="px-4 py-2 text-sm text-white/70 border border-white/20 rounded-lg hover:bg-white/5 transition-colors">{t.cookieBanner.decline}</button>
          <button onClick={() => handleChoice('accepted')} className="px-4 py-2 text-sm bg-[#c9a84c] text-[#0a0a0f] font-semibold rounded-lg hover:bg-[#e8d5a3] transition-colors">{t.cookieBanner.accept}</button>
        </div>
      </div>
    </div>
  );
}
