import { useState } from 'react';
import { Search, Instagram, Facebook, Linkedin, ArrowUp } from 'lucide-react';

function App() {
  const [lang, setLang] = useState<'en' | 'fi'>('en');

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const twitterIcon = (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );

  return (
    <div className="min-h-screen w-full bg-[#f0ece0] relative">
      {/* ====== HERO SECTION ====== */}
      <section className="relative w-full h-screen min-h-[600px] flex">
        {/* LEFT SIDEBAR PANEL */}
        <div className="w-[28%] min-w-[260px] max-w-[340px] bg-[#f0ece0] flex flex-col justify-between py-6 px-8 relative z-20">
          {/* Logo */}
          <div className="logo-font text-[22px] tracking-wide text-black leading-tight">
            MRIntelligence
          </div>

          {/* Vertical Title + Description */}
          <div className="flex items-center gap-4 flex-1 mt-12 mb-8">
            <h1
              className="vertical-text text-[26px] font-light text-black tracking-wide leading-none whitespace-nowrap"
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              Qualified Business Consultancy
            </h1>
            <p
              className="vertical-text text-[11px] text-black/60 leading-relaxed tracking-wide max-h-[340px]"
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru
            </p>
          </div>

          {/* Social Icons */}
          <div className="flex items-center gap-3">
            <a href="#" className="social-icon" aria-label="Instagram">
              <Instagram size={16} strokeWidth={1.5} />
            </a>
            <a href="#" className="social-icon" aria-label="Twitter">
              {twitterIcon}
            </a>
            <a href="#" className="social-icon" aria-label="Facebook">
              <Facebook size={16} strokeWidth={1.5} />
            </a>
            <a href="#" className="social-icon" aria-label="LinkedIn">
              <Linkedin size={16} strokeWidth={1.5} />
            </a>
          </div>
        </div>

        {/* RIGHT IMAGE AREA */}
        <div className="flex-1 relative">
          {/* Navigation Bar */}
          <nav className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-10 py-5">
            <div className="flex-1" />
            <ul className="flex items-center gap-8">
              {['Home', 'Services', 'Project', 'Pages', 'Blog', 'Contact Us'].map((item) => (
                <li key={item}>
                  <a href="#" className="nav-link">
                    {item}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href="#"
                  className="text-sm font-semibold text-black px-5 py-2 border border-black/20 rounded-full hover:bg-black hover:text-white transition-all duration-300"
                >
                  Get Pro
                </a>
              </li>
              <li>
                <button
                  className="w-11 h-11 rounded bg-[#c5e236] flex items-center justify-center hover:bg-[#b5d22e] transition-colors shadow-sm"
                  aria-label="Search"
                >
                  <Search size={18} strokeWidth={2} className="text-black" />
                </button>
              </li>
            </ul>
          </nav>

          {/* Hero Image */}
          <div className="absolute inset-0">
            <img
              src="/hero-business.jpg"
              alt="Business consultancy meeting"
              className="w-full h-full object-cover"
            />
            {/* Subtle overlay for text readability */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-transparent pointer-events-none" />
          </div>
        </div>
      </section>

      {/* ====== BOTTOM BAR ====== */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3">
        <div className="flex items-center bg-white rounded-full shadow-lg border border-gray-100 overflow-hidden">
          <button
            onClick={() => setLang('en')}
            className={`lang-btn flex items-center gap-2 ${lang === 'en' ? 'active' : ''}`}
          >
            <span className="text-base">🇬🇧</span>
            <span>English</span>
          </button>
          <div className="w-px h-5 bg-gray-200" />
          <button
            onClick={() => setLang('fi')}
            className={`lang-btn flex items-center gap-2 ${lang === 'fi' ? 'active' : ''}`}
          >
            <span className="text-base">🇫🇮</span>
            <span>Suomi</span>
          </button>
        </div>
      </div>

      {/* Back to Top Button */}
      <button
        onClick={scrollToTop}
        className="fixed bottom-6 right-6 z-50 w-12 h-12 rounded-full bg-[#c5e236] flex items-center justify-center hover:bg-[#b5d22e] transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1"
        aria-label="Back to top"
      >
        <ArrowUp size={20} strokeWidth={2.5} className="text-black" />
      </button>
    </div>
  );
}

export default App;
