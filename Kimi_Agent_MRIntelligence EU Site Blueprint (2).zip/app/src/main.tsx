import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './index.css';
import LanguageSelector from './pages/LanguageSelector';
import HomePage from './pages/HomePage';
import PrivacyPage from './pages/PrivacyPage';
import TermsPage from './pages/TermsPage';
import AdminPage from './pages/AdminPage';
import { TRPCProvider } from "@/providers/trpc"

const langs = ['pt', 'es', 'dk', 'it', 'en'] as const;

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <TRPCProvider>
        <Routes>
          <Route path="/" element={<LanguageSelector />} />
          {langs.map((lang) => (
            <Route key={lang} path={`/${lang}`} element={<HomePage lang={lang} />} />
          ))}
          {langs.map((lang) => (
            <Route key={`${lang}-privacy`} path={`/${lang}/privacy`} element={<PrivacyPage lang={lang} />} />
          ))}
          {langs.map((lang) => (
            <Route key={`${lang}-terms`} path={`/${lang}/terms`} element={<TermsPage lang={lang} />} />
          ))}
          <Route path="/admin" element={<AdminPage />} />
        </Routes>
      </TRPCProvider>
    </BrowserRouter>
  </StrictMode>
);
