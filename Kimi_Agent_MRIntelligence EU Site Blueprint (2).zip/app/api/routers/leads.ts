import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { leads } from "@db/schema";
import { desc, eq } from "drizzle-orm";

export const leadsRouter = createRouter({
  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        email: z.string().email().max(255),
        phone: z.string().max(50).optional(),
        caseType: z.string().min(1).max(100),
        amount: z.string().optional(),
        description: z.string().optional(),
        language: z.string().max(10).default("en"),
        gdprConsent: z.string().max(10).default("yes"),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const amountNum = input.amount ? parseFloat(input.amount) : null;
      
      const result = await db.insert(leads).values({
        name: input.name,
        email: input.email,
        phone: input.phone || null,
        caseType: input.caseType,
        amount: amountNum ? String(amountNum) : null,
        description: input.description || null,
        language: input.language,
        gdprConsent: input.gdprConsent,
        status: "new",
      });

      return { success: true, id: Number(result[0].insertId) };
    }),

  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(leads).orderBy(desc(leads.createdAt));
  }),

  updateStatus: publicQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["new", "contacted", "in_progress", "resolved", "closed"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(leads)
        .set({ status: input.status })
        .where(eq(leads.id, input.id));
      return { success: true };
    }),
});
