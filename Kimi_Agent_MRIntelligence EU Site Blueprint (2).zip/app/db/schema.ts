import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
  decimal,
} from "drizzle-orm/mysql-core";

export const leads = mysqlTable("leads", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  caseType: varchar("case_type", { length: 100 }).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }),
  description: text("description"),
  language: varchar("language", { length: 10 }).notNull().default("en"),
  gdprConsent: varchar("gdpr_consent", { length: 10 }).notNull().default("yes"),
  status: varchar("status", { length: 50 }).notNull().default("new"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});
