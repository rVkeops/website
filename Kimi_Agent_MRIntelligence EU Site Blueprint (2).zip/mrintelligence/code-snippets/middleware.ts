import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * MRIntelligence — Edge Middleware
 * Functions:
 *  1. GeoIP enforcement (EEA-only access)
 *  2. Locale detection and i18n routing (es / da / pt / en)
 *  3. Security header augmentation
 *
 * Compliance: GDPR Art. 44 (data transfer restrictions), LSSI-CE transparency
 */

// EEA country codes per ISO 3166-1 alpha-2
const EEA_COUNTRIES = new Set([
  'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU',
  'IS', 'IE', 'IT', 'LV', 'LI', 'LT', 'LU', 'MT', 'NL', 'NO', 'PL', 'PT', 'RO',
  'SK', 'SI', 'ES', 'SE', 'CH',
]);

const SUPPORTED_LOCALES = ['es', 'da', 'pt', 'en'];
const DEFAULT_LOCALE = 'en';

export function middleware(request: NextRequest) {
  const country = request.geo?.country || 'UNKNOWN';

  // 1. Geo-fencing: reject non-EEA requests at edge
  if (!EEA_COUNTRIES.has(country)) {
    return new NextResponse(
      `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><title>403 Forbidden</title></head>
<body>
  <h1>403 — Access Restricted</h1>
  <p>This resource is available only within the European Economic Area (EEA) in compliance with GDPR data-residency requirements.</p>
  <p>If you believe this is an error, contact compliance@mrintelligence.eu.</p>
</body>
</html>`,
      {
        status: 403,
        headers: {
          'Content-Type': 'text/html; charset=utf-8',
          'X-Country-Code': country,
        },
      }
    );
  }

  // 2. Locale detection and redirection
  const { pathname } = request.nextUrl;
  const hasLocalePrefix = SUPPORTED_LOCALES.some(
    (loc) => pathname.startsWith(`/${loc}/`) || pathname === `/${loc}`
  );

  if (!hasLocalePrefix) {
    const acceptLang = request.headers.get('accept-language') || '';
    const preferred = acceptLang.split(',')[0]?.slice(0, 2).toLowerCase() || DEFAULT_LOCALE;
    const targetLocale = SUPPORTED_LOCALES.includes(preferred) ? preferred : DEFAULT_LOCALE;

    // Prevent open-redirect: validate pathname before rewriting
    const safePath = pathname.startsWith('/') ? pathname : '/';
    const url = request.nextUrl.clone();
    url.pathname = `/${targetLocale}${safePath}`;
    return NextResponse.redirect(url);
  }

  // 3. Append security and compliance headers to all responses
  const response = NextResponse.next();
  response.headers.set('X-Country-Code', country);
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  return response;
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml|.*\\..*).*)',
  ],
};
