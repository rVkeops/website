/**
 * MRIntelligence — Client-Side PII Encryption Module
 * ------------------------------------------------------------------------
 * Uses the Web Crypto API (AES-256-GCM + RSA-OAEP envelope encryption).
 * No plaintext PII leaves the browser boundary before reaching the sovereign
 * EU backend.
 *
 * Compliance: GDPR Art. 32 (security of processing), Art. 25 (PbD)
 * Algorithm: AES-256-GCM (data) + RSA-OAEP-4096 (key wrapping) + Ed25519 (non-repudiation)
 */

const AES_ALGORITHM: AesKeyAlgorithm = { name: 'AES-GCM', length: 256 };
const RSA_ALGORITHM: RsaHashedKeyAlgorithm = { name: 'RSA-OAEP', hash: 'SHA-256' };

interface EncryptedPayload {
  iv: string; // base64
  ciphertext: string; // base64
  encryptedKey: string; // base64 — AES key wrapped with RSA-OAEP
  signature: string; // base64 — proof of origin
  version: string;
  timestamp: string;
}

/**
 * Encrypt a lead form submission in the browser.
 * @param plaintext - Form fields as key-value pairs (PII)
 * @param rsaPublicKeySpki - Base64-encoded SPKI public key (RSA-4096)
 * @returns EncryptedPayload ready for transmission to /api/lead
 */
export async function encryptLeadForm(
  plaintext: Record<string, string>,
  rsaPublicKeySpki: string
): Promise<EncryptedPayload> {
  // 1. Generate ephemeral AES-256-GCM key
  const aesKey = await crypto.subtle.generateKey(AES_ALGORITHM, true, ['encrypt']);

  // 2. Encode plaintext
  const encoder = new TextEncoder();
  const data = encoder.encode(JSON.stringify(plaintext));

  // 3. Generate 96-bit IV (AES-GCM standard)
  const iv = crypto.getRandomValues(new Uint8Array(12));

  // 4. Encrypt plaintext
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, aesKey, data);

  // 5. Import RSA public key
  const spki = Uint8Array.from(atob(rsaPublicKeySpki), (c) => c.charCodeAt(0));
  const publicKey = await crypto.subtle.importKey(
    'spki',
    spki,
    RSA_ALGORITHM,
    false,
    ['wrapKey']
  );

  // 6. Wrap AES key with RSA-OAEP
  const encryptedKey = await crypto.subtle.wrapKey('raw', aesKey, publicKey, RSA_ALGORITHM);

  // 7. Sign payload with ephemeral Ed25519 session key
  const signature = await signPayload(ciphertext, iv);

  return {
    iv: arrayBufferToBase64(iv),
    ciphertext: arrayBufferToBase64(ciphertext),
    encryptedKey: arrayBufferToBase64(encryptedKey),
    signature,
    version: '2026.05.07-v1',
    timestamp: new Date().toISOString(),
  };
}

/**
 * Sign the ciphertext+IV combination using the session-derived Ed25519 key.
 * In production, the Ed25519 keypair is generated at consent acceptance and
 * stored in sessionStorage (never localStorage) with a 30-minute TTL.
 */
async function signPayload(ciphertext: ArrayBuffer, iv: Uint8Array): Promise<string> {
  const combined = new Uint8Array(iv.length + new Uint8Array(ciphertext).length);
  combined.set(iv, 0);
  combined.set(new Uint8Array(ciphertext), iv.length);

  // Production note: replace with Ed25519 sign() via session keypair
  // Simplified to SHA-256 digest for architecture demonstration
  const hash = await crypto.subtle.digest('SHA-256', combined);
  return arrayBufferToBase64(hash);
}

function arrayBufferToBase64(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = buffer instanceof ArrayBuffer ? new Uint8Array(buffer) : buffer;
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}
