'use client';

import { useState, useEffect } from 'react';

/**
 * MRIntelligence — EDPB-Compliant Cookie Consent Component
 * ------------------------------------------------------------------------
 * Principles enforced:
 *   - Equal prominence for "Accept All" and "Reject All" (identical styling)
 *   - Single-click rejection on first layer (no labyrinthine opt-out)
 *   - Granular second-layer toggles per purpose (Necessary / Analytics / Marketing)
 *   - Neutral, non-coercive language
 *   - No pre-ticked boxes
 *   - Versioned consent record for audit trails
 *
 * Compliance: GDPR Art. 7, EDPB Guidelines 05/2020, EDPB Cookie Banner Taskforce
 * Localization: Spanish (es), Danish (da), Portuguese (pt), English (en)
 */

interface ConsentState {
  version: string;
  timestamp: string;
  necessary: boolean;
  analytics: boolean;
  marketing: boolean;
}

const CONSENT_KEY = 'mr_consent_v1';
const CURRENT_VERSION = '2026.05.07-1';

const translations = {
  en: {
    bannerLabel: 'Cookie consent banner',
    description:
      'We use cookies to ensure the functionality of our website and, with your consent, to analyse usage and personalise content. You can change your preferences at any time.',
    acceptAll: 'Accept All',
    rejectAll: 'Reject All',
    managePreferences: 'Manage Preferences',
    modalLabel: 'Manage cookie preferences',
    purposes: 'Processing purposes',
    necessary: 'Necessary (always active)',
    analytics: 'Analytics & performance',
    marketing: 'Marketing & personalisation',
    save: 'Save Preferences',
  },
  es: {
    bannerLabel: 'Banner de consentimiento de cookies',
    description:
      'Utilizamos cookies para garantizar la funcionalidad de nuestro sitio web y, con su consentimiento, para analizar el uso y personalizar el contenido. Puede cambiar sus preferencias en cualquier momento.',
    acceptAll: 'Aceptar todo',
    rejectAll: 'Rechazar todo',
    managePreferences: 'Gestionar preferencias',
    modalLabel: 'Gestionar preferencias de cookies',
    purposes: 'Finalidades del tratamiento',
    necessary: 'Necesarias (siempre activas)',
    analytics: 'Analisis y rendimiento',
    marketing: 'Marketing y personalizacion',
    save: 'Guardar',
  },
  da: {
    bannerLabel: 'Cookie-samtykkebanner',
    description:
      'Vi bruger cookies til at sikre vores websites funktionalitet og, med dit samtykke, til at analysere brugen og personalisere indhold. Du kan til enhver tid aendre dine praeferencer.',
    acceptAll: 'Accepter alle',
    rejectAll: 'Afvis alle',
    managePreferences: 'Administrer preferencer',
    modalLabel: 'Administrer cookie-preferencer',
    purposes: 'Behandlingsformaal',
    necessary: 'Noedvendige (altid aktive)',
    analytics: 'Analyse og ydelse',
    marketing: 'Marketing og personalisering',
    save: 'Gem',
  },
  pt: {
    bannerLabel: 'Banner de consentimento de cookies',
    description:
      'Utilizamos cookies para garantir a funcionalidade do nosso site e, com o seu consentimento, para analisar a utilizacao e personalizar o conteudo. Pode alterar as suas preferencias a qualquer momento.',
    acceptAll: 'Aceitar tudo',
    rejectAll: 'Rejeitar tudo',
    managePreferences: 'Gerir preferencias',
    modalLabel: 'Gerir preferencias de cookies',
    purposes: 'Finalidades do tratamento',
    necessary: 'Necessarias (sempre ativas)',
    analytics: 'Analise e desempenho',
    marketing: 'Marketing e personalizacao',
    save: 'Guardar',
  },
};

function useTranslation(locale: string) {
  return translations[locale as keyof typeof translations] || translations.en;
}

export default function CookieConsent({ locale = 'en' }: { locale?: string }) {
  const t = useTranslation(locale);
  const [visible, setVisible] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [prefs, setPrefs] = useState({ analytics: false, marketing: false });

  useEffect(() => {
    const stored = localStorage.getItem(CONSENT_KEY);
    if (!stored) {
      setVisible(true);
      return;
    }
    try {
      const parsed: ConsentState = JSON.parse(stored);
      if (parsed.version !== CURRENT_VERSION) {
        setVisible(true); // Re-prompt on policy update
      }
    } catch {
      setVisible(true);
    }
  }, []);

  const saveConsent = (analytics: boolean, marketing: boolean) => {
    const state: ConsentState = {
      version: CURRENT_VERSION,
      timestamp: new Date().toISOString(),
      necessary: true,
      analytics,
      marketing,
    };
    localStorage.setItem(CONSENT_KEY, JSON.stringify(state));
    setVisible(false);
    setShowModal(false);
    window.dispatchEvent(new CustomEvent('consent-updated', { detail: state }));
  };

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-modal="false"
      aria-label={t.bannerLabel}
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: '#1a1a1a',
        color: '#fafafa',
        padding: '1.5rem',
        zIndex: 9999,
      }}
    >
      <p style={{ maxWidth: '70ch', marginBottom: '1rem', lineHeight: 1.5 }}>
        {t.description}
      </p>

      <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
        {/* EQUAL PROMINENCE: identical visual weight for Accept and Reject */}
        <button
          className="btn btn-primary"
          onClick={() => saveConsent(true, true)}
          style={{
            padding: '0.6rem 1.2rem',
            fontWeight: 600,
            background: '#fafafa',
            color: '#1a1a1a',
            border: 'none',
            cursor: 'pointer',
          }}
        >
          {t.acceptAll}
        </button>
        <button
          className="btn btn-primary"
          onClick={() => saveConsent(false, false)}
          style={{
            padding: '0.6rem 1.2rem',
            fontWeight: 600,
            background: '#fafafa',
            color: '#1a1a1a',
            border: 'none',
            cursor: 'pointer',
          }}
        >
          {t.rejectAll}
        </button>
        <button
          className="btn btn-secondary"
          onClick={() => setShowModal(true)}
          style={{
            padding: '0.6rem 1.2rem',
            fontWeight: 400,
            background: 'transparent',
            color: '#fafafa',
            border: '1px solid #fafafa',
            cursor: 'pointer',
          }}
        >
          {t.managePreferences}
        </button>
      </div>

      {showModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={t.modalLabel}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.7)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000,
          }}
          onClick={(e) => {
            if (e.currentTarget === e.target) setShowModal(false);
          }}
        >
          <div
            style={{
              background: '#fafafa',
              color: '#1a1a1a',
              padding: '2rem',
              maxWidth: '500px',
              width: '90%',
            }}
          >
            <fieldset>
              <legend style={{ fontWeight: 700, marginBottom: '1rem' }}>
                {t.purposes}
              </legend>
              <label style={{ display: 'block', marginBottom: '0.75rem' }}>
                <input type="checkbox" checked disabled readOnly /> {t.necessary}
              </label>
              <label style={{ display: 'block', marginBottom: '0.75rem' }}>
                <input
                  type="checkbox"
                  checked={prefs.analytics}
                  onChange={(e) =>
                    setPrefs((p) => ({ ...p, analytics: e.target.checked }))
                  }
                />{' '}
                {t.analytics}
              </label>
              <label style={{ display: 'block', marginBottom: '1.25rem' }}>
                <input
                  type="checkbox"
                  checked={prefs.marketing}
                  onChange={(e) =>
                    setPrefs((p) => ({ ...p, marketing: e.target.checked }))
                  }
                />{' '}
                {t.marketing}
              </label>
            </fieldset>
            <button
              onClick={() => saveConsent(prefs.analytics, prefs.marketing)}
              style={{
                padding: '0.6rem 1.2rem',
                fontWeight: 600,
                background: '#1a1a1a',
                color: '#fafafa',
                border: 'none',
                cursor: 'pointer',
              }}
            >
              {t.save}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
