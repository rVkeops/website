import React from 'react';

/**
 * MRIntelligence — Legal Transparency Hub: Aviso Legal (Spain)
 * ------------------------------------------------------------------------
 * Complies with LSSI-CE (Ley 34/2002, de 11 de julio) Article 10.
 * All information must be "easy, direct and permanent" for recipients
 * and competent bodies.
 *
 * Jurisdiction: Spain (AEPD oversight)
 * Required fields: a) through g) per Art. 10.1 LSSI-CE
 */

interface AvisoLegalData {
  companyName: string;
  domicile: string;
  email: string;
  phone: string;
  commercialRegistry: string;
  registryEntry: string;
  nif: string;
  professionalAssociation?: string;
  associationNumber?: string;
  academicTitle?: string;
  titleIssuingState?: string;
  professionalRulesUrl?: string;
  codesOfConduct?: string[];
}

const defaultData: AvisoLegalData = {
  companyName: 'MRIntelligence Solutions S.L.',
  domicile: 'Calle de la Princesa 31, 28008 Madrid, Spain',
  email: 'legal@mrintelligence.eu',
  phone: '+34 91 123 4567',
  commercialRegistry: 'Registro Mercantil de Madrid',
  registryEntry: 'Tomo 12345, Libro 0, Folio 67, Hoja M-987654',
  nif: 'B-12345678',
  professionalAssociation: 'Colegio Oficial de Ingenieros en Informatica',
  associationNumber: 'COI-12345-ES',
  academicTitle: 'Ingeniero en Informatica',
  titleIssuingState: 'Spain',
  professionalRulesUrl: 'https://www.coi.org/codigo-deontologico',
  codesOfConduct: ['EN 301 549', 'WCAG 2.1 AAA', 'ISO 27001'],
};

export default function AvisoLegal({ data = defaultData }: { data?: AvisoLegalData }) {
  return (
    <article aria-labelledby="aviso-legal-title">
      <h1 id="aviso-legal-title">Aviso Legal</h1>
      <p>
        En cumplimiento del artículo 10 de la Ley 34/2002, de 11 de julio, de Servicios de la
        Sociedad de la Información y de Comercio Electrónico (LSSI-CE), a continuación se facilita
        la información general de este sitio web.
      </p>

      <section aria-labelledby="datos-titular">
        <h2 id="datos-titular">1. Datos del titular</h2>
        <dl>
          <dt>Razón social / denominación:</dt>
          <dd>{data.companyName}</dd>

          <dt>Domicilio social:</dt>
          <dd>{data.domicile}</dd>

          <dt>Correo electrónico:</dt>
          <dd>
            <a href={`mailto:${data.email}`}>{data.email}</a>
          </dd>

          <dt>Teléfono de contacto:</dt>
          <dd>
            <a href={`tel:${data.phone.replace(/\s/g, '')}`}>{data.phone}</a>
          </dd>

          <dt>Número de Identificación Fiscal (NIF):</dt>
          <dd>{data.nif}</dd>
        </dl>
      </section>

      <section aria-labelledby="registro-mercantil">
        <h2 id="registro-mercantil">2. Inscripción en el Registro Mercantil</h2>
        <p>
          {data.companyName} está inscrita en el <strong>{data.commercialRegistry}</strong>, con
          los siguientes datos de inscripción: <em>{data.registryEntry}</em>.
        </p>
      </section>

      {data.professionalAssociation && (
        <section aria-labelledby="profesion-regulada">
          <h2 id="profesion-regulada">3. Profesión regulada</h2>
          <dl>
            <dt>Colegio profesional:</dt>
            <dd>{data.professionalAssociation}</dd>

            <dt>Número de colegiado:</dt>
            <dd>{data.associationNumber}</dd>

            <dt>Título académico:</dt>
            <dd>{data.academicTitle}</dd>

            <dt>Estado miembro de expedición:</dt>
            <dd>{data.titleIssuingState}</dd>

            {data.professionalRulesUrl && (
              <>
                <dt>Normas profesionales aplicables:</dt>
                <dd>
                  <a href={data.professionalRulesUrl} rel="noopener noreferrer">
                    {data.professionalRulesUrl}
                  </a>
                </dd>
              </>
            )}
          </dl>
        </section>
      )}

      <section aria-labelledby="codigos-conducta">
        <h2 id="codigos-conducta">4. Códigos de conducta</h2>
        <p>
          {data.companyName} se adhiere voluntariamente a los siguientes códigos de conducta y
          estándares de calidad:
        </p>
        <ul>
          {data.codesOfConduct?.map((code) => (
            <li key={code}>{code}</li>
          ))}
        </ul>
      </section>

      <section aria-labelledby="precios">
        <h2 id="precios">5. Precios</h2>
        <p>
          Los precios de los servicios de consultoría y auditoría se indican en las propuestas
          comerciales específicas. Todos los precios incluyen el Impuesto sobre el Valor Añadido
          (IVA) aplicable en España, salvo indicación expresa en contrario.
        </p>
      </section>

      <section aria-labelledby="responsabilidad">
        <h2 id="responsabilidad">6. Responsabilidad y aviso legal</h2>
        <p>
          El contenido de este sitio web tiene finalidad meramente informativa y no constituye una
          oferta vinculante. MRIntelligence no se responsabiliza de los daños derivados del acceso
          o uso del sitio, salvo que resulten de dolo o negligencia grave comprobada.
        </p>
        <p>
          Para cualquier controversia, las partes se someten a los Juzgados y Tribunales de Madrid,
          con renuncia expresa a cualquier otro fuero que pudiera corresponderles.
        </p>
      </section>

      <footer>
        <p>
          <small>
            Última actualización: <time dateTime="2026-05-07">7 de mayo de 2026</time>. Este
            documento se revisa trimestralmente para garantizar su exactitud y cumplimiento de la
            normativa vigente.
          </small>
        </p>
      </footer>
    </article>
  );
}
