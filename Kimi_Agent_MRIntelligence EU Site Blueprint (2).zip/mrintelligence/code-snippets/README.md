# MRIntelligence — Sovereign Architecture Code Snippets

## Overview
This package contains production-ready TypeScript modules for the MRIntelligence institutional-grade platform. All code is engineered for Next.js 14+ Static Site Generation (SSG) with strict TypeScript, zero client-side data leakage, and full EU regulatory compliance (GDPR, DORA, LSSI-CE, WCAG 2.1 AAA).

## File Structure

```
code-snippets/
├── next.config.ts              # Security headers + SSG export configuration
├── middleware.ts               # GeoIP enforcement + locale routing
├── lib/
│   └── crypto.ts               # Client-side PII encryption (AES-256-GCM + RSA-OAEP)
└── components/
    └── CookieConsent.tsx       # EDPB-compliant, multilingual consent layer
```

## Quick Start

1. **Install dependencies**
   ```bash
   npm install next react react-dom typescript @types/react @types/node
   ```

2. **Copy files into your Next.js project**
   - `next.config.ts` → project root
   - `middleware.ts` → project root (App Router)
   - `lib/crypto.ts` → `src/lib/crypto.ts`
   - `components/CookieConsent.tsx` → `src/components/CookieConsent.tsx`

3. **Configure environment variables**
   ```bash
   # .env.local
   NEXT_PUBLIC_API_BASE=https://api.mrintelligence.eu
   NEXT_PUBLIC_RSA_PUBKEY_B64=<base64-encoded RSA-4096 SPKI>
   ```

4. **Build for sovereign static export**
   ```bash
   npm run build
   # Output: ./dist — deployable to any EU object store
   ```

## Security Notes

- **No plaintext PII leaves the browser.** The `crypto.ts` module encrypts all lead-form data with AES-256-GCM before transmission. The backend decrypts via PKCS#11 HSM calls.
- **GeoIP enforcement** in `middleware.ts` rejects non-EEA traffic at the edge, ensuring GDPR Article 44 compliance.
- **Cookie consent** uses identical visual weight for "Accept All" and "Reject All" per EDPB Cookie Banner Taskforce requirements. No dark patterns.
- **Security headers** achieve Mozilla Observatory A+ grading and enforce TLS 1.3-only, CSP Level 3, and COOP/COEP isolation.

## Compliance Mapping

| Code Module | Regulation | Article / Standard |
|-------------|------------|-------------------|
| `next.config.ts` | GDPR | Art. 32 (security of processing) |
| `next.config.ts` | DORA | Art. 9 (network and information security) |
| `middleware.ts` | GDPR | Art. 44 (data transfer restrictions) |
| `lib/crypto.ts` | GDPR | Art. 25, Art. 32 (PbD + encryption) |
| `CookieConsent.tsx` | GDPR | Art. 7 (conditions for consent) |
| `CookieConsent.tsx` | EDPB | Guidelines 05/2020 + Taskforce Report |
| All modules | WCAG 2.1 | Level AAA (keyboard operable, screen-reader compatible) |

## License
CONFIDENTIAL — Proprietary to MRIntelligence. Distribution outside the organization requires written authorization from the Compliance Officer.
